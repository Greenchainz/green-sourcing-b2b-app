-- drizzle/migrations/0001_add_image_urls.sql
-- Adds image storage columns to materials and suppliers tables
-- Run via: npm run db:push or drizzle-kit migrate

ALTER TABLE materials ADD COLUMN IF NOT EXISTS "imageUrl" text;
ALTER TABLE materials ADD COLUMN IF NOT EXISTS "imageBlobName" text;
ALTER TABLE materials ADD COLUMN IF NOT EXISTS "imageUpdatedAt" timestamp;
ALTER TABLE materials ADD COLUMN IF NOT EXISTS "isFeatured" boolean DEFAULT false;
ALTER TABLE materials ADD COLUMN IF NOT EXISTS "featuredUntil" timestamp;

ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "isFeatured" boolean DEFAULT false;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "featuredUntil" timestamp;

-- Index for featured catalog queries (fast lookup for top-of-catalog placement)
CREATE INDEX IF NOT EXISTS idx_materials_featured ON materials ("isFeatured", "category");
CREATE INDEX IF NOT EXISTS idx_suppliers_featured ON suppliers ("isFeatured");
