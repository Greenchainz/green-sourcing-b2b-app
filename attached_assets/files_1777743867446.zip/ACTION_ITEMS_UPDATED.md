# GreenChainz — Full Action Items Checklist
_Updated: May 1, 2026_

---

## 🗄️ Database
- [ ] Run `npm run db:push` to apply migration (adds imageUrl, isFeatured, featuredUntil columns)
- [ ] Add `hasProfile: boolean` to `/api/supplier/dashboard` Express handler — derive from `ctx.user.id`, remove `supplier_id=1` default

---

## ☁️ Azure
- [ ] Create `material-images` blob container with public blob read access:
  ```
  az storage container create \
    --name material-images \
    --account-name <your-storage-account> \
    --public-access blob
  ```
- [ ] Confirm `AZURE_STORAGE_ACCOUNT_NAME` is set in Container Apps env vars
- [ ] Confirm `AZURE_STORAGE_CONNECTION_STRING` is set in `.env.local` for local dev
- [ ] Add `NEXT_PUBLIC_ALLOWED_ORIGINS` to env vars:
  ```
  NEXT_PUBLIC_ALLOWED_ORIGINS=https://greenchainz.com,https://staging.greenchainz.com,http://localhost:5173
  ```

---

## 📁 Code — Copy Files Into Repo

### Supplier Onboarding
- [ ] `app/supplier/onboarding/page.tsx`
- [ ] `app/supplier/page.tsx` (updated dashboard with profile gate)

### Catalog & Quote Flow
- [ ] `app/catalog/page.tsx` (browse + quote basket)
- [ ] `app/quote/review/page.tsx` (quote review + submission)
- [ ] `app/catalog/components/ArchitectMaterialCard.tsx` (architect-first card redesign)

### Featured Placement
- [ ] `server/routers/featuredRouter.ts`
- [ ] `components/catalog/FeaturedRow.tsx`
- [ ] `app/admin/featured/page.tsx`

### Image Pipeline
- [ ] `server/services/material-image-service.ts`
- [ ] `app/api/supplier/upload-image/route.ts`
- [ ] `app/api/admin/scrape-images/route.ts`
- [ ] `components/supplier/MaterialImageUpload.tsx`
- [ ] `drizzle/migrations/0001_add_image_urls.sql`

### Supplier Landing Page
- [ ] `app/suppliers/page.tsx` (claim your profile — v2)
- [ ] `app/api/supplier/request-onboarding/route.ts`
- [ ] `server/routers/manufacturerSearchRouter.ts`

### Role-Aware Dashboard
- [ ] `app/dashboard/page.tsx` (server component, role redirect)
- [ ] `app/dashboard/architect/page.tsx`
- [ ] `app/dashboard/admin/page.tsx`

### Stub Pages
- [ ] `app/rfqs/page.tsx`
- [ ] `app/materials/page.tsx`
- [ ] `app/tools/page.tsx`

---

## 🔧 Backend Wiring (small code edits)

- [ ] Register `featuredRouter` in `server/routers/index.ts`:
  ```ts
  import { featuredRouter } from './featuredRouter'
  // add: featured: featuredRouter
  ```
- [ ] Register `manufacturerSearchRouter` in `server/routers/index.ts`:
  ```ts
  import { manufacturerSearchRouter } from './manufacturerSearchRouter'
  // add: manufacturerSearch: manufacturerSearchRouter
  ```
- [ ] Add `FeaturedRow` to `app/catalog/page.tsx` above the main grid
- [ ] Replace `MaterialCard` with `ArchitectMaterialCard` in catalog page
- [ ] Wire `/api/trpc/supplierOnboarding.submitOnboarding` so new onboarding page can POST to it
- [ ] Set `isBeta: true` on new `buyerSubscriptions` and `supplierSubscriptions` inserts on signup
- [ ] Add `BETA_ACCESS_ENABLED=true` to `.env`
- [ ] Replace `setTimeout` mock in `app/quote/review/page.tsx` with real tRPC `rfq.createBatch` call
- [ ] In catalog query — add featured-first ordering:
  ```ts
  .orderBy(desc((materials as any).isFeatured), desc(materials.sustainabilityScore))
  ```
- [ ] Replace `MOCK_RESULTS` in `app/suppliers/page.tsx` with real `manufacturerSearch.search` tRPC call

---

## 🌐 Middleware / CORS
- [ ] Apply CORS middleware patch from security review (restricts wildcard origin to allowlist)

---

## 💰 Monetization (not urgent — flip when ready)
- [ ] Set featured supplier slots via admin panel at `/admin/featured`
- [ ] When ready to monetize: set `isBeta: false` for new signups, flip `BETA_ACCESS_ENABLED=false`
- [ ] Uncomment paywall check in `rfqRouter.ts` (comment already marks the spot)

---

## 🧹 Cleanup (low priority)
- [ ] Archive or remove legacy `client/src/pages/SupplierOnboarding.tsx` once new version confirmed working
- [ ] Audit `app/routes/*.js` legacy routing files — mark as legacy or delete
- [ ] Replace emoji/text icons in `LayoutContent` NAV_ITEMS with lucide-react icons
- [ ] Personalise supplier sidebar — replace hardcoded "Supplier Admin" / "My Company Inc." with real auth context

---

## 🔐 Auth (do when ready — not urgent)
- [ ] Try incognito window first — if login works consistently there, just clear browser cache for microsoft.com (2 min fix, zero code changes)
- [ ] When ready for full fix: confirm new app (`8b597068`) redirect URIs include localhost and production URL, then swap Client ID + Tenant ID in env vars, test locally first, THEN deactivate old app in Azure

---

## 📋 Business / Ops
- [ ] Update founding spots counter in `app/suppliers/page.tsx` as you onboard suppliers (currently shows 47)
- [ ] Set white-glove onboarding pricing: $500, $750, or $1,500 per supplier
- [ ] Write outreach email template for founding supplier campaign
- [ ] Confirm `jerit@greenchainz.com` email address is correct in supplier landing page footer
- [ ] Get Forma extension repo name confirmed and share with Claude next session
