// server/routes/supplierDashboard.ts  (or wherever /api/supplier/dashboard lives)
// ADD `hasProfile` to the response so the frontend gate works.
//
// Find your dashboard handler and ensure it returns this shape:
//
//   const supplier = await db.query.suppliers.findFirst({
//     where: eq(suppliers.userId, ctx.user.id),
//   })
//
//   return {
//     hasProfile: !!supplier,
//     activeRfqs: supplier?.activeRfqs ?? 0,
//     profileViews30d: supplier?.profileViews30d ?? 0,
//     completionScore: supplier?.completionScore ?? 0,
//     avgResponseTime: supplier?.avgResponseTime ?? '—',
//     recentOpportunities: supplier?.recentOpportunities ?? [],
//   }
//
// REMOVE the `supplier_id=1` demo default entirely.
// Always derive identity from ctx.user.id (Easy Auth → X-MS-CLIENT-PRINCIPAL-ID header).
//
// If you want the shape to stay backward-compatible for now,
// just add `hasProfile: !!supplier` to whatever you already return.
