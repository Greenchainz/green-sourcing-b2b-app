// BACKEND_PATCH_NOTES_BETA.ts
//
// ─── LAUNCH STRATEGY: Everyone gets premium via isBeta ─────────────────────────
//
// In server/routers/authRouter.ts (or wherever you create users on first login):
// After inserting the user, auto-create their subscription as beta = true.
//
// For BUYERS (architects):
//   await db.insert(buyerSubscriptions).values({
//     userId: newUser.id,
//     tier: 'standard',        // gives rfqSubmission + all core features
//     status: 'active',
//     isBeta: true,            // ← this makes checkBuyerFeatureAccess return premium for everything
//   })
//
// For SUPPLIERS:
//   await db.insert(supplierSubscriptions).values({
//     supplierId: newSupplier.id,
//     tier: 'premium',
//     status: 'active',
//     isBeta: true,            // ← same — getSupplierTierLimits returns premium limits
//   })
//
// When you're ready to monetize (after 50 suppliers / 200 architects):
//   1. Change default isBeta: false for NEW signups only
//   2. Existing beta users keep their access — never retroactively downgrade
//   3. Add a "Founding Member" badge check: if (sub.isBeta) show <FoundingBadge />
//
// ─── RFQ PAYWALL (dormant until flip) ──────────────────────────────────────────
//
// In server/routers/rfqRouter.ts createRfq procedure, add BEFORE insert:
//
//   // PAYWALL — uncomment when monetization is live
//   // const canSubmit = await checkBuyerFeatureAccess(ctx.user.id, 'rfqSubmission')
//   // if (!canSubmit) throw new TRPCError({ code: 'FORBIDDEN', message: 'Upgrade to submit RFQs' })
//
// In server/routers/rfqRouter.ts getAvailableRfqs for suppliers:
//
//   // PAYWALL — uncomment when monetization is live  
//   // const tier = await getSupplierTierLimits(supplier.id)
//   // if (!tier.features.receiverRfqs) throw new TRPCError({ code: 'FORBIDDEN' })
//   // For delay: if (sub.tier === 'free') where(gte(rfqs.createdAt, sevenDaysAgo))
//
// ─── FOUNDING MEMBER ENV FLAG ───────────────────────────────────────────────────
//
// Add to .env:
//   BETA_ACCESS_ENABLED=true   # set to false to activate paywall for new signups
//
// In signup handler:
//   const isBeta = process.env.BETA_ACCESS_ENABLED === 'true'
