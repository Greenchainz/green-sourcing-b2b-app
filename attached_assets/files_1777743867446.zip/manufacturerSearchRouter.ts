// server/routers/manufacturerSearchRouter.ts
// Add this to your appRouter as: manufacturerSearch: manufacturerSearchRouter
//
// Replaces the MOCK_RESULTS in the landing page with real DB data.
// Wire it in app/suppliers/page.tsx by replacing searchManufacturers() with:
//
//   const res = await fetch(
//     `/api/trpc/manufacturerSearch.search?input=${encodeURIComponent(JSON.stringify({ q }))}`,
//     { credentials: 'include' }
//   )
//   const data = await res.json()
//   return data.result?.data ?? []

import { z } from 'zod'
import { router, publicProcedure } from '../trpc'
import { getDb } from '../db'
import { materials, manufacturers, suppliers } from '../../drizzle/schema'
import { ilike, sql, eq } from 'drizzle-orm'

export const manufacturerSearchRouter = router({
  /**
   * Public search — no auth required.
   * Used on the supplier landing page to show a company their listing status.
   */
  search: publicProcedure
    .input(z.object({ q: z.string().min(2).max(100) }))
    .query(async ({ input }) => {
      const db = await getDb()
      if (!db) return []

      // Find manufacturers matching the query
      const results = await db
        .select({
          id: manufacturers.id,
          name: manufacturers.name,
          website: manufacturers.website,
          verified: manufacturers.verified,
          logoUrl: manufacturers.logoUrl,
        })
        .from(manufacturers)
        .where(ilike(manufacturers.name, `%${input.q}%`))
        .limit(8)

      if (results.length === 0) return []

      // For each manufacturer, get product count and health indicators
      const enriched = await Promise.all(
        results.map(async (mfr) => {
          const stats = await db
            .select({
              productCount: sql<number>`count(*)`.as('productCount'),
              hasImages: sql<boolean>`bool_or(${(materials as any).imageUrl} is not null)`.as('hasImages'),
              hasEpds: sql<boolean>`bool_or(${materials.hasEpd})`.as('hasEpds'),
              categories: sql<string[]>`array_agg(distinct ${materials.category})`.as('categories'),
            })
            .from(materials)
            .where(eq(materials.manufacturerId, mfr.id))

          // Check if a supplier has claimed this manufacturer's profile
          const claimed = await db
            .select({ id: suppliers.id })
            .from(suppliers)
            .where(eq(suppliers.manufacturerId, mfr.id))
            .limit(1)

          return {
            manufacturer: mfr.name,
            productCount: Number(stats[0]?.productCount ?? 0),
            hasImages: Boolean(stats[0]?.hasImages),
            hasEpds: Boolean(stats[0]?.hasEpds),
            isVerified: mfr.verified ?? false,
            isClaimed: claimed.length > 0,
            categories: (stats[0]?.categories ?? []).filter(Boolean).slice(0, 3),
          }
        })
      )

      return enriched
    }),
})
