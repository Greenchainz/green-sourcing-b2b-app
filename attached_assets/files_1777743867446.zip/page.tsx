// app/materials/page.tsx
import { PlaceholderPage } from '@/components/PlaceholderPage'
export default function MaterialsPage() {
  return <PlaceholderPage title="My Materials" description="Manage your material specifications, compare EPD scores, and track your project's embodied carbon." />
}
