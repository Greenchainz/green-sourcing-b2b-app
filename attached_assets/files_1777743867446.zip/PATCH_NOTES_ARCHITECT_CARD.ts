// PATCH_NOTES_ARCHITECT_CARD.ts
//
// ─── Drop-in replacement for MaterialCard ─────────────────────────────────────
//
// In app/catalog/page.tsx (both the new one we built and the legacy one):
//
// BEFORE:
//   import MaterialCard from '@/app/components/catalog/MaterialCard'
//   ...
//   <MaterialCard material={m} ... />
//
// AFTER:
//   import { ArchitectMaterialCard } from './components/ArchitectMaterialCard'
//   ...
//   <ArchitectMaterialCard
//     material={m}
//     inBasket={basketIds.has(m.id)}
//     onAddToQuote={addToBasket}
//     onRemoveFromQuote={removeFromBasket}
//   />
//
// ─── Map your existing material shape to ArchitectMaterial ────────────────────
//
// The new card expects these fields (all optional except id, name, manufacturer,
// category, sustainabilityScore):
//
//   imageUrl           → materials.imageUrl (from image pipeline)
//   gwpValue           → materials.gwpValue
//   gwpUnit            → materials.gwpUnit
//   categoryBaselineGwp → materials.categoryBaselineGwp (from GCS spec)
//   hasEpd             → materials.hasEpd
//   hasHpd             → materials.hasHpd
//   hasFsc             → materials.hasFsc
//   hasC2c             → materials.hasC2c
//   hasGreenguard      → materials.hasGreenguard
//   usManufactured     → materials.usManufactured
//   recycledContentPct → materials.recycledContentPct
//   leadTimeDays       → materials.leadTimeDays
//   verified           → materials.verified (boolean, not 0/1)
//   isFeatured         → materials.isFeatured (from featured pipeline)
//
// All of these already exist in your Drizzle schema.
// The card gracefully handles null/undefined for every optional field.
//
// ─── No image yet? ───────────────────────────────────────────────────────────
//
// If imageUrl is null, the card shows a dark green gradient placeholder
// with a leaf icon and the category name. Looks intentional, not broken.
// Run the image scraper (admin/scrape-images) to fill images in.
//
// ─── Carbon bar baseline ─────────────────────────────────────────────────────
//
// If categoryBaselineGwp is null, the bar uses gwpValue * 1.5 as a rough
// baseline so it still renders. For accurate bars, populate
// materials.categoryBaselineGwp from your EC3 category averages.
