// components/PlaceholderPage.tsx
import { Construction } from 'lucide-react'
import * as Icons from 'lucide-react'

interface PlaceholderPageProps {
  title: string
  description: string
  icon?: keyof typeof Icons
}

export function PlaceholderPage({ title, description, icon = 'Construction' }: PlaceholderPageProps) {
  // Dynamically resolve the icon from lucide-react
  const LucideIcon = (Icons[icon] as React.ElementType) ?? Icons.Construction

  return (
    <div className="flex items-center justify-center min-h-[60vh] p-8">
      <div className="max-w-sm text-center">
        <div className="w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-5">
          <LucideIcon className="w-8 h-8 text-green-400" />
        </div>
        <h1 className="text-xl font-bold text-white mb-2">{title}</h1>
        <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  )
}
