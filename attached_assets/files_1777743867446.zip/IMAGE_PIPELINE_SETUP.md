// IMAGE_PIPELINE_SETUP.md
//
// ─── What was built ────────────────────────────────────────────────────────────
//
// 1. server/services/material-image-service.ts
//    - scrapeManufacturerImages(manufacturerId, websiteUrl) — Playwright scraper
//    - uploadMaterialImageFromBuffer(materialId, supplierId, buffer, contentType) — direct upload
//    - backfillMissingImages() — runs scraper across all verified manufacturers
//
// 2. app/api/supplier/upload-image/route.ts
//    - POST endpoint for supplier self-serve image uploads
//    - Validates auth, file type, size, and material ownership
//    - Stores in Azure Blob → updates materials.imageUrl in DB
//
// 3. app/api/admin/scrape-images/route.ts
//    - POST endpoint for white-glove onboarding: triggers Playwright scraper
//    - Body: { manufacturerId: 123, websiteUrl: "https://..." }
//    - Body: { backfill: true } to scrape ALL manufacturers missing images
//
// 4. components/supplier/MaterialImageUpload.tsx
//    - Drag-and-drop + click-to-upload React component
//    - Instant local preview, uploads to /api/supplier/upload-image
//    - Drop into any supplier product form
//
// 5. drizzle/migrations/0001_add_image_urls.sql
//    - Adds imageUrl, imageBlobName, imageUpdatedAt to materials table
//    - Adds isFeatured, featuredUntil to materials and suppliers tables
//
// ─── Required env vars ─────────────────────────────────────────────────────────
//
// Already in your stack — no new vars needed IF Blob Storage is configured:
//   AZURE_STORAGE_ACCOUNT_NAME=<your storage account>     ← prod (managed identity)
//   AZURE_STORAGE_CONNECTION_STRING=<connection string>   ← local dev
//
// Create the container in Azure Portal or via CLI:
//   az storage container create \
//     --name material-images \
//     --account-name <your-storage-account> \
//     --public-access blob
//
// The "blob" public access means images are directly CDN-servable without SAS tokens.
// This is intentional — product images are public catalog content.
//
// ─── Run the DB migration ──────────────────────────────────────────────────────
//
//   npm run db:push
//
// Or apply the SQL directly if you prefer:
//   psql $DATABASE_URL < drizzle/migrations/0001_add_image_urls.sql
//
// ─── How to use during white-glove onboarding ──────────────────────────────────
//
// After you set up a supplier profile manually:
//
//   curl -X POST https://greenchainz.com/api/admin/scrape-images \
//     -H "Content-Type: application/json" \
//     -H "x-ms-client-principal-id: <your-admin-user-id>" \
//     -d '{ "manufacturerId": 5, "websiteUrl": "https://carboncure.com" }'
//
// It returns a JSON report of how many images were found and uploaded.
// Check materials in Drizzle Studio to confirm imageUrl is populated.
//
// ─── Featured placement (monetization) ─────────────────────────────────────────
//
// To mark a supplier as featured (paid placement):
//   UPDATE suppliers SET "isFeatured" = true, "featuredUntil" = NOW() + INTERVAL '30 days'
//   WHERE id = <supplierId>;
//
// In catalog query, order featured materials first:
//   .orderBy(desc(materials.isFeatured), desc(materials.sustainabilityScore))
//
// The isFeatured + featuredUntil columns are ready — just wire the admin UI when needed.
