# GreenChainz — Action Items Checklist
_Generated: May 1, 2026_

---

## 🗄️ Database
- [ ] Run `npm run db:push` to apply the new migration (adds imageUrl, isFeatured, featuredUntil columns)
- [ ] Add `hasProfile: boolean` to `/api/supplier/dashboard` Express handler — derive from `ctx.user.id`, remove the `supplier_id=1` demo default

---

## ☁️ Azure
- [ ] Create `material-images` blob container with **public blob read access**:
  ```
  az storage container create \
    --name material-images \
    --account-name <your-storage-account> \
    --public-access blob
  ```
- [ ] Confirm `AZURE_STORAGE_ACCOUNT_NAME` is set in production env vars (Container Apps)
- [ ] Confirm `AZURE_STORAGE_CONNECTION_STRING` is set in `.env.local` for local dev

---

## 📁 Code — Copy Files Into Repo
- [ ] `app/supplier/onboarding/page.tsx` — new onboarding flow
- [ ] `app/supplier/page.tsx` — updated dashboard with profile gate
- [ ] `app/catalog/page.tsx` — material browse + quote basket
- [ ] `app/quote/review/page.tsx` — quote review + submission
- [ ] `app/rfqs/page.tsx` — stub page
- [ ] `app/catalog/page.tsx` — stub (already above)
- [ ] `app/materials/page.tsx` — stub page
- [ ] `app/tools/page.tsx` — stub page
- [ ] `server/services/material-image-service.ts` — image scraper + upload service
- [ ] `app/api/supplier/upload-image/route.ts` — supplier image upload endpoint
- [ ] `app/api/admin/scrape-images/route.ts` — admin scraper trigger endpoint
- [ ] `components/supplier/MaterialImageUpload.tsx` — drag-and-drop upload component
- [ ] `drizzle/migrations/0001_add_image_urls.sql` — DB migration

---

## 🔧 Backend Wiring (small code edits)
- [ ] In `server/routers/rfqRouter.ts` — wire `/api/trpc/supplierOnboarding.submitOnboarding` so the new onboarding page can POST to it
- [ ] In user/supplier signup handler — set `isBeta: true` on new `buyerSubscriptions` and `supplierSubscriptions` inserts so everyone gets premium access during launch period
- [ ] Add `BETA_ACCESS_ENABLED=true` to `.env`
- [ ] In `app/quote/review/page.tsx` — replace the `setTimeout` mock with real tRPC `rfq.createBatch` call when that router is ready

---

## 🌐 Middleware / CORS
- [ ] Add `NEXT_PUBLIC_ALLOWED_ORIGINS` to env vars:
  ```
  NEXT_PUBLIC_ALLOWED_ORIGINS=https://greenchainz.com,https://staging.greenchainz.com,http://localhost:5173
  ```
- [ ] Apply the CORS middleware patch from the security review (restricts wildcard origin)

---

## 💰 Monetization (when you're ready — not urgent)
- [ ] Set up featured supplier slots: `UPDATE suppliers SET "isFeatured" = true, "featuredUntil" = NOW() + INTERVAL '30 days' WHERE id = <id>;`
- [ ] When paywall is ready to flip on: set `isBeta: false` for new signups only, flip `BETA_ACCESS_ENABLED=false`
- [ ] Uncomment paywall check in `rfqRouter.ts` (comment is already in the code marking the spot)

---

## 🧹 Cleanup (lower priority)
- [ ] Remove or archive legacy `client/src/pages/SupplierOnboarding.tsx` once new app router version is confirmed working
- [ ] Audit `app/routes/*.js` legacy routing files — mark as legacy or delete
- [ ] Replace emoji/text icons in `LayoutContent` NAV_ITEMS with lucide-react icons
- [ ] Personalise supplier sidebar — replace hardcoded "Supplier Admin" / "My Company Inc." with real auth context data

---

## 📋 Business / Ops (no code needed)
- [ ] Set up white-glove onboarding pricing: decide on $500, $750, or $1,500 per supplier
- [ ] Write outreach email template for founding supplier campaign
- [ ] Decide founding member offer: free premium for 12 months in exchange for early onboarding
- [ ] Get repo name for Forma extension confirmed (forma-dash-something) and share with Claude next session
