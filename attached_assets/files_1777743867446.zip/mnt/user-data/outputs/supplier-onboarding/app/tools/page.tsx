// app/tools/page.tsx
import { PlaceholderPage } from '@/components/PlaceholderPage'
export default function ToolsPage() {
  return <PlaceholderPage title="Carbon Compare" description="Side-by-side embodied carbon analysis for materials — powered by EC3 and EPD International data." />
}
