// app/supplier/page.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
  FileText,
  Eye,
  CheckCircle2,
  Clock,
  AlertCircle,
  ArrowRight,
  Upload,
  Package,
  UserPlus,
  Loader2,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface DashboardMetrics {
  activeRfqs: number
  profileViews30d: number
  completionScore: number
  avgResponseTime: string
  recentOpportunities: {
    id: string
    title: string
    budget: string
    deadline: string
    status: string
  }[]
  hasProfile: boolean
}

export default function SupplierDashboardPage() {
  const [data, setData] = useState<DashboardMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/supplier/dashboard', { credentials: 'include' })
      .then(async (res) => {
        if (!res.ok) throw new Error(`Error ${res.status}`)
        return res.json()
      })
      .then((json) => setData(json))
      .catch((err: unknown) => {
        const msg = err instanceof Error ? err.message : 'Failed to load dashboard'
        setError(msg)
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-green-400" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-8">
        <Alert className="border-red-500/20 bg-red-500/10">
          <AlertCircle className="w-4 h-4 text-red-400" />
          <AlertDescription className="text-red-300">
            {error} — try refreshing the page.
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  // ── No profile yet: show onboarding gate ────────────────────────────────────
  if (!data?.hasProfile || (data.completionScore ?? 0) < 10) {
    return (
      <div className="p-8 max-w-2xl">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-1">Welcome to GreenChainz</h1>
          <p className="text-gray-400 text-sm">Let's get your supplier profile set up.</p>
        </div>

        <Card className="bg-gradient-to-br from-green-500/10 to-transparent border-green-500/20">
          <CardContent className="pt-8 pb-6 flex flex-col gap-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <h2 className="text-white font-semibold text-lg mb-1">
                  Complete your supplier profile
                </h2>
                <p className="text-gray-400 text-sm leading-relaxed">
                  Architects search GreenChainz for verified sustainable materials every day.
                  Your profile is how they find you — and how they trust you.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center text-sm">
              {[
                { icon: '⏱', label: '5 min setup' },
                { icon: '🏗', label: 'Free to join' },
                { icon: '🌿', label: 'LEED-ready' },
              ].map((item) => (
                <div
                  key={item.label}
                  className="bg-white/5 rounded-lg py-3 border border-white/10"
                >
                  <div className="text-xl mb-1">{item.icon}</div>
                  <div className="text-gray-400 text-xs">{item.label}</div>
                </div>
              ))}
            </div>

            <Button
              asChild
              className="bg-green-500 hover:bg-green-400 text-black font-semibold w-full"
            >
              <Link href="/supplier/onboarding">
                Start Supplier Onboarding
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ── Profile exists: show full dashboard ─────────────────────────────────────
  const metrics = [
    {
      label: 'Active RFQs',
      value: data.activeRfqs ?? 0,
      icon: FileText,
      suffix: '',
    },
    {
      label: 'Profile Views (30d)',
      value: data.profileViews30d ?? 0,
      icon: Eye,
      suffix: '',
    },
    {
      label: 'Profile Completion',
      value: data.completionScore ?? 0,
      icon: CheckCircle2,
      suffix: '%',
    },
    {
      label: 'Avg Response Time',
      value: data.avgResponseTime ?? '—',
      icon: Clock,
      suffix: '',
      isString: true,
    },
  ]

  const quickActions = [
    {
      label: 'Upload New EPD',
      icon: Upload,
      href: '/supplier/certs',
      description: 'Add verified sustainability credentials',
    },
    {
      label: 'Update Product Catalog',
      icon: Package,
      href: '/supplier/products',
      description: 'Add or edit your material listings',
    },
    {
      label: 'Add Team Member',
      icon: UserPlus,
      href: '/supplier/settings',
      description: 'Invite colleagues to manage your profile',
    },
  ]

  return (
    <div className="p-8 space-y-8">
      {/* Incomplete profile banner */}
      {(data.completionScore ?? 0) < 80 && (
        <Alert className="border-yellow-500/20 bg-yellow-500/10">
          <AlertCircle className="w-4 h-4 text-yellow-400" />
          <AlertDescription className="text-yellow-300 flex items-center justify-between w-full">
            <span>
              Your profile is {data.completionScore}% complete. Finish it to get more visibility.
            </span>
            <Button
              asChild
              variant="outline"
              size="sm"
              className="ml-4 border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/10"
            >
              <Link href="/supplier/onboarding">Complete Profile</Link>
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div>
        <h1 className="text-2xl font-bold text-white mb-1">Supplier Dashboard</h1>
        <p className="text-gray-400 text-sm">Your performance at a glance.</p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((m) => {
          const Icon = m.icon
          return (
            <Card key={m.label} className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="pt-5 pb-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-gray-400 text-xs font-medium uppercase tracking-wide">
                    {m.label}
                  </span>
                  <Icon className="w-4 h-4 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white">
                  {m.isString ? m.value : `${m.value}${m.suffix}`}
                </div>
                {m.label === 'Profile Completion' && (
                  <Progress
                    value={data.completionScore}
                    className="mt-2 h-1 bg-white/10 [&>div]:bg-green-500"
                  />
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Opportunities */}
        <div className="lg:col-span-2 space-y-3">
          <h2 className="text-white font-semibold text-sm uppercase tracking-wide">
            Recent Opportunities
          </h2>
          {(data.recentOpportunities ?? []).length === 0 ? (
            <Card className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="py-10 text-center">
                <FileText className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No active RFQs yet.</p>
                <p className="text-gray-600 text-xs mt-1">
                  Complete your profile to start receiving opportunities.
                </p>
              </CardContent>
            </Card>
          ) : (
            data.recentOpportunities.map((rfq) => (
              <Link key={rfq.id} href={`/supplier/rfqs/${rfq.id}`}>
                <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/30 transition-all cursor-pointer">
                  <CardContent className="py-4 flex items-center justify-between">
                    <div>
                      <p className="text-white text-sm font-medium">{rfq.title}</p>
                      <p className="text-gray-500 text-xs mt-0.5">
                        Budget: {rfq.budget} · Due {rfq.deadline}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        className={
                          rfq.status === 'open'
                            ? 'bg-green-500/10 text-green-400 border-green-500/20'
                            : 'bg-white/5 text-gray-400 border-white/10'
                        }
                      >
                        {rfq.status}
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-gray-600" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))
          )}
        </div>

        {/* Quick Actions */}
        <div className="space-y-3">
          <h2 className="text-white font-semibold text-sm uppercase tracking-wide">
            Quick Actions
          </h2>
          {quickActions.map((action) => {
            const Icon = action.icon
            return (
              <Link key={action.label} href={action.href}>
                <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/30 transition-all cursor-pointer">
                  <CardContent className="py-4 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{action.label}</p>
                      <p className="text-gray-500 text-xs">{action.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-600 ml-auto" />
                  </CardContent>
                </Card>
              </Link>
            )
          })}

          {/* EPD promo */}
          <Card className="bg-gradient-to-br from-green-500/10 to-transparent border-green-500/20">
            <CardContent className="py-4">
              <p className="text-green-400 text-xs font-medium mb-1">💡 Did you know?</p>
              <p className="text-gray-300 text-xs leading-relaxed">
                Suppliers with verified EPDs receive 3× more architect inquiries on GreenChainz.
              </p>
              <Link
                href="/supplier/certs"
                className="text-green-400 text-xs mt-2 flex items-center gap-1 hover:text-green-300"
              >
                Upload EPDs <ArrowRight className="w-3 h-3" />
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
