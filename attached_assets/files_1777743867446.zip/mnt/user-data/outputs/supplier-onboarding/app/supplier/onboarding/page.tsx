// app/supplier/onboarding/page.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import {
  Building2,
  Package,
  Award,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

// ─── Schemas (mirror supplierOnboardingRouter input exactly) ───────────────────

const companyInfoSchema = z.object({
  companyName: z.string().min(2, 'Company name must be at least 2 characters'),
  contactName: z.string().min(2, 'Contact name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  website: z.string().url('Please enter a valid website URL').optional().or(z.literal('')),
  phone: z.string().optional(),
  description: z.string().min(10, 'Please provide at least 10 characters').optional().or(z.literal('')),
})

const MATERIAL_CATEGORIES = [
  'Concrete & Masonry',
  'Steel & Metal',
  'Timber & Wood',
  'Glass & Glazing',
  'Insulation',
  'Roofing',
  'Flooring',
  'Cladding & Facades',
  'MEP Systems',
  'Finishes & Coatings',
  'Structural Systems',
  'Waterproofing',
]

const CERTIFICATIONS = [
  'LEED',
  'WELL',
  'FSC',
  'GreenGuard',
  'Cradle to Cradle',
  'EPD (Environmental Product Declaration)',
  'ISO 14001',
  'ENERGY STAR',
  'Living Building Challenge',
  'BREEAM',
]

const materialsSchema = z.object({
  materialCategories: z.array(z.string()).min(1, 'Please select at least one material category'),
})

const certificationsSchema = z.object({
  certifications: z.array(z.string()),
  hasEPDs: z.boolean(),
})

const fullSchema = companyInfoSchema.merge(materialsSchema).merge(certificationsSchema)
type FormData = z.infer<typeof fullSchema>

// ─── Step indicator ────────────────────────────────────────────────────────────

const STEPS = [
  { id: 1, label: 'Company Info', icon: Building2 },
  { id: 2, label: 'Materials', icon: Package },
  { id: 3, label: 'Certifications', icon: Award },
]

function StepIndicator({ currentStep }: { currentStep: number }) {
  return (
    <div className="flex items-center justify-center gap-0 mb-8">
      {STEPS.map((step, idx) => {
        const Icon = step.icon
        const isComplete = currentStep > step.id
        const isCurrent = currentStep === step.id
        return (
          <div key={step.id} className="flex items-center">
            <div className="flex flex-col items-center gap-1">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                  isComplete
                    ? 'bg-green-500 border-green-500 text-white'
                    : isCurrent
                    ? 'bg-green-500/10 border-green-500 text-green-400'
                    : 'bg-white/5 border-white/20 text-gray-500'
                }`}
              >
                {isComplete ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <Icon className="w-5 h-5" />
                )}
              </div>
              <span
                className={`text-xs font-medium ${
                  isCurrent ? 'text-green-400' : isComplete ? 'text-green-500' : 'text-gray-500'
                }`}
              >
                {step.label}
              </span>
            </div>
            {idx < STEPS.length - 1 && (
              <div
                className={`h-0.5 w-16 mx-2 mb-5 transition-all ${
                  currentStep > step.id ? 'bg-green-500' : 'bg-white/10'
                }`}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

// ─── Checkbox group helper ─────────────────────────────────────────────────────

function CheckboxGroup({
  label,
  options,
  selected,
  onChange,
  error,
}: {
  label: string
  options: string[]
  selected: string[]
  onChange: (values: string[]) => void
  error?: string
}) {
  const toggle = (value: string) => {
    onChange(
      selected.includes(value) ? selected.filter((v) => v !== value) : [...selected, value]
    )
  }
  return (
    <div className="space-y-3">
      <Label className="text-white font-medium">{label}</Label>
      <div className="grid grid-cols-2 gap-2">
        {options.map((option) => (
          <div
            key={option}
            onClick={() => toggle(option)}
            className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-all text-sm ${
              selected.includes(option)
                ? 'bg-green-500/10 border-green-500/50 text-green-300'
                : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20 hover:text-white'
            }`}
          >
            <Checkbox
              checked={selected.includes(option)}
              onCheckedChange={() => toggle(option)}
              className="border-white/20 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
            />
            <span>{option}</span>
          </div>
        ))}
      </div>
      {error && (
        <p className="text-red-400 text-sm flex items-center gap-1">
          <AlertCircle className="w-3.5 h-3.5" /> {error}
        </p>
      )}
    </div>
  )
}

// ─── Main component ────────────────────────────────────────────────────────────

export default function SupplierOnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)

  const form = useForm<FormData>({
    resolver: zodResolver(fullSchema),
    defaultValues: {
      companyName: '',
      contactName: '',
      email: '',
      website: '',
      phone: '',
      description: '',
      materialCategories: [],
      certifications: [],
      hasEPDs: false,
    },
    mode: 'onChange',
  })

  const { register, watch, setValue, formState: { errors }, trigger } = form
  const watchedCategories = watch('materialCategories')
  const watchedCerts = watch('certifications')
  const watchedHasEPDs = watch('hasEPDs')

  // Step validation before advancing
  const advanceStep = async () => {
    let valid = false
    if (step === 1) {
      valid = await trigger(['companyName', 'contactName', 'email', 'website'])
    } else if (step === 2) {
      valid = await trigger(['materialCategories'])
    }
    if (valid) setStep((s) => s + 1)
  }

  const onSubmit = async (data: FormData) => {
    setSubmitting(true)
    try {
      // tRPC batch call to Express bridge
      const body = {
        0: {
          json: {
            companyName: data.companyName,
            contactName: data.contactName,
            email: data.email,
            website: data.website || null,
            phone: data.phone || null,
            description: data.description || null,
            materialCategories: data.materialCategories,
            certifications: data.certifications,
            hasEPDs: data.hasEPDs,
          },
        },
      }

      const res = await fetch('/api/trpc/supplierOnboarding.submitOnboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body[0].json),
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err?.message ?? `Server error ${res.status}`)
      }

      setDone(true)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong'
      toast.error(message)
    } finally {
      setSubmitting(false)
    }
  }

  // ── Completion screen ────────────────────────────────────────────────────────
  if (done) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-6">
        <Card className="bg-[#111] border-[#1f1f1f] max-w-md w-full text-center">
          <CardContent className="pt-10 pb-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold text-white">You're in the network!</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              Your supplier profile is submitted and pending verification. Architects can start
              discovering your materials while we review your credentials.
            </p>
            <div className="flex flex-col gap-2 w-full pt-2">
              <Button
                onClick={() => router.push('/supplier')}
                className="w-full bg-green-500 hover:bg-green-400 text-black font-semibold"
              >
                Go to Supplier Dashboard
              </Button>
              <Button
                variant="ghost"
                onClick={() => router.push('/supplier/products')}
                className="w-full text-gray-400 hover:text-white"
              >
                Upload Your First Product
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-10 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="bg-green-500/10 text-green-400 border-green-500/20 mb-3">
            Supplier Onboarding
          </Badge>
          <h1 className="text-3xl font-bold text-white mb-2">Join the GreenChainz Network</h1>
          <p className="text-gray-400 text-sm">
            Tell architects who you are — your profile becomes their trusted green material source.
          </p>
        </div>

        <StepIndicator currentStep={step} />

        <Card className="bg-[#111] border-[#1f1f1f]">
          {/* ── Step 1: Company Info ──────────────────────────────────────────── */}
          {step === 1 && (
            <>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-green-400" />
                  Company Information
                </CardTitle>
                <CardDescription className="text-gray-400">
                  This is what architects see when they find your profile.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-white" htmlFor="companyName">
                      Company Name <span className="text-red-400">*</span>
                    </Label>
                    <Input
                      id="companyName"
                      placeholder="Acme Green Materials"
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500"
                      {...register('companyName')}
                    />
                    {errors.companyName && (
                      <p className="text-red-400 text-xs flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.companyName.message}
                      </p>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-white" htmlFor="contactName">
                      Your Name <span className="text-red-400">*</span>
                    </Label>
                    <Input
                      id="contactName"
                      placeholder="Jane Smith"
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500"
                      {...register('contactName')}
                    />
                    {errors.contactName && (
                      <p className="text-red-400 text-xs flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.contactName.message}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-white" htmlFor="email">
                    Business Email <span className="text-red-400">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="jane@acmegreenco.com"
                    className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500"
                    {...register('email')}
                  />
                  {errors.email && (
                    <p className="text-red-400 text-xs flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {errors.email.message}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-white" htmlFor="website">
                      Website
                    </Label>
                    <Input
                      id="website"
                      placeholder="https://acmegreenco.com"
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500"
                      {...register('website')}
                    />
                    {errors.website && (
                      <p className="text-red-400 text-xs flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.website.message}
                      </p>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-white" htmlFor="phone">
                      Phone
                    </Label>
                    <Input
                      id="phone"
                      placeholder="+1 (555) 000-0000"
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500"
                      {...register('phone')}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-white" htmlFor="description">
                    Tell architects about your company
                  </Label>
                  <textarea
                    id="description"
                    rows={3}
                    placeholder="We manufacture low-carbon concrete alternatives using recycled industrial byproducts..."
                    className="w-full rounded-md bg-white/5 border border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 px-3 py-2 text-sm resize-none"
                    {...register('description')}
                  />
                  {errors.description && (
                    <p className="text-red-400 text-xs flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {errors.description.message}
                    </p>
                  )}
                </div>
              </CardContent>
            </>
          )}

          {/* ── Step 2: Material Categories ───────────────────────────────────── */}
          {step === 2 && (
            <>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Package className="w-5 h-5 text-green-400" />
                  Material Categories
                </CardTitle>
                <CardDescription className="text-gray-400">
                  These help architects filter and trust your materials. Select everything that applies.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <CheckboxGroup
                  label=""
                  options={MATERIAL_CATEGORIES}
                  selected={watchedCategories}
                  onChange={(vals) => setValue('materialCategories', vals, { shouldValidate: true })}
                  error={errors.materialCategories?.message as string | undefined}
                />
              </CardContent>
            </>
          )}

          {/* ── Step 3: Certifications ────────────────────────────────────────── */}
          {step === 3 && (
            <>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Award className="w-5 h-5 text-green-400" />
                  Certifications & Compliance
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Verified credentials build trust and unlock more RFQs. Select what you currently hold.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <CheckboxGroup
                  label="Certifications"
                  options={CERTIFICATIONS}
                  selected={watchedCerts}
                  onChange={(vals) => setValue('certifications', vals)}
                />

                <div
                  onClick={() => setValue('hasEPDs', !watchedHasEPDs)}
                  className={`flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-all ${
                    watchedHasEPDs
                      ? 'bg-green-500/10 border-green-500/50'
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  <Checkbox
                    checked={watchedHasEPDs}
                    onCheckedChange={(v) => setValue('hasEPDs', v === true)}
                    className="mt-0.5 border-white/20 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
                  />
                  <div>
                    <p className="text-white font-medium text-sm">
                      We have Environmental Product Declarations (EPDs)
                    </p>
                    <p className="text-gray-400 text-xs mt-0.5">
                      EPDs are the gold standard for verified sustainability claims. You can upload
                      them after your profile is live.
                    </p>
                  </div>
                </div>
              </CardContent>
            </>
          )}

          {/* ── Navigation ────────────────────────────────────────────────────── */}
          <div className="flex items-center justify-between px-6 pb-6 pt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => (step === 1 ? router.push('/supplier') : setStep((s) => s - 1))}
              className="text-gray-400 hover:text-white"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              {step === 1 ? 'Cancel' : 'Back'}
            </Button>

            {step < 3 ? (
              <Button
                type="button"
                onClick={advanceStep}
                className="bg-green-500 hover:bg-green-400 text-black font-semibold"
              >
                Continue
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <Button
                type="button"
                onClick={form.handleSubmit(onSubmit)}
                disabled={submitting}
                className="bg-green-500 hover:bg-green-400 text-black font-semibold min-w-[140px]"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-1" />
                    Submit Profile
                  </>
                )}
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}
