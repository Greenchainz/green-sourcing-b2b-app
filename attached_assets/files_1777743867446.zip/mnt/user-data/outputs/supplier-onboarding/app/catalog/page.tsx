// app/catalog/page.tsx
import { PlaceholderPage } from '@/components/PlaceholderPage'
export default function CatalogPage() {
  return <PlaceholderPage title="Material Catalog" description="Browse verified sustainable materials from GreenChainz suppliers — filterable by category, certification, and carbon footprint." />
}
