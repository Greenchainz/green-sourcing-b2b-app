// app/rfqs/page.tsx
import { PlaceholderPage } from '@/components/PlaceholderPage'

export default function RfqsPage() {
  return (
    <PlaceholderPage
      title="RFQ Dashboard"
      description="Manage your requests for quote — post new RFQs, review supplier responses, and track project timelines."
    />
  )
}
