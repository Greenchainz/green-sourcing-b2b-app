// app/api/admin/scrape-images/route.ts
/**
 * POST /api/admin/scrape-images
 *
 * Admin-only endpoint to trigger the Playwright image scraper.
 * Used during white-glove onboarding — you call this after setting up
 * a supplier's profile to auto-pull product images from their website.
 *
 * Body:
 *   { manufacturerId: number }          ← scrape all materials for this manufacturer
 *   { backfill: true }                  ← scrape ALL manufacturers missing images (slow)
 *
 * Auth: admin role check via Easy Auth + users.role
 */

import { NextRequest, NextResponse } from 'next/server'
import { getDb } from '@/server/db'
import { users } from '@/drizzle/schema'
import { eq } from 'drizzle-orm'
import {
  scrapeManufacturerImages,
  backfillMissingImages,
} from '@/server/services/material-image-service'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  // ── Admin auth check ──────────────────────────────────────────────────────
  const userId = req.headers.get('x-ms-client-principal-id')
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const db = await getDb()
  if (!db) return NextResponse.json({ error: 'Database unavailable' }, { status: 503 })

  const user = await db
    .select({ role: users.role })
    .from(users)
    .where(eq(users.id, Number(userId)))
    .limit(1)

  if (user[0]?.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden — admin only' }, { status: 403 })
  }

  // ── Parse request ─────────────────────────────────────────────────────────
  let body: { manufacturerId?: number; backfill?: boolean; websiteUrl?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  // ── Backfill all ──────────────────────────────────────────────────────────
  if (body.backfill === true) {
    console.log('[AdminScraper] Starting full backfill...')
    const result = await backfillMissingImages()
    return NextResponse.json(result)
  }

  // ── Single manufacturer ───────────────────────────────────────────────────
  if (!body.manufacturerId) {
    return NextResponse.json({ error: 'manufacturerId or backfill required' }, { status: 400 })
  }

  if (!body.websiteUrl) {
    // Look up website from DB
    const { manufacturers } = await import('@/drizzle/schema')
    const mfr = await db
      .select({ website: manufacturers.website, name: manufacturers.name })
      .from(manufacturers)
      .where(eq(manufacturers.id, body.manufacturerId))
      .limit(1)

    if (!mfr.length || !mfr[0].website) {
      return NextResponse.json(
        { error: 'Manufacturer not found or has no website URL' },
        { status: 404 }
      )
    }

    body.websiteUrl = mfr[0].website
  }

  console.log(`[AdminScraper] Scraping manufacturer ${body.manufacturerId} at ${body.websiteUrl}`)

  try {
    const results = await scrapeManufacturerImages(body.manufacturerId, body.websiteUrl)
    const succeeded = results.filter((r) => r.success).length
    const failed = results.filter((r) => !r.success).length

    return NextResponse.json({
      manufacturerId: body.manufacturerId,
      total: results.length,
      succeeded,
      failed,
      results,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Scrape failed'
    console.error('[AdminScraper] Error:', err)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
