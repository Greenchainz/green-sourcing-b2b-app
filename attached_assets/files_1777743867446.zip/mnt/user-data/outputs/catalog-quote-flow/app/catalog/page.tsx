// app/catalog/page.tsx
'use client'

import { useState, useMemo, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
  Search,
  SlidersHorizontal,
  ShoppingCart,
  Leaf,
  Award,
  Zap,
  ChevronDown,
  X,
  ArrowRight,
  CheckCircle2,
  Filter,
  Star,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'

// ─── Types ────────────────────────────────────────────────────────────────────

interface Material {
  id: string
  name: string
  manufacturer: string
  category: string
  subcategory: string
  description: string
  gwpValue: number
  gwpUnit: string
  sustainabilityScore: number
  certifications: string[]
  hasEpd: boolean
  verified: boolean
  imageUrl?: string
  priceUnit: string
  leadTimeDays: number
  supplierId: string
  supplierName: string
}

interface QuoteItem {
  material: Material
  quantity?: number
  note?: string
}

// ─── Mock data (replace with tRPC call) ──────────────────────────────────────

const MOCK_MATERIALS: Material[] = [
  {
    id: '1', name: 'CarbonCure Ready Mix Concrete', manufacturer: 'CarbonCure Technologies',
    category: 'Concrete', subcategory: 'Ready Mix', description: 'CO₂-injected concrete with verified embodied carbon reduction of 5–6% per pour.',
    gwpValue: 280, gwpUnit: 'kgCO₂e/m³', sustainabilityScore: 88, certifications: ['EPD', 'LEED'],
    hasEpd: true, verified: true, priceUnit: 'per yard³', leadTimeDays: 3,
    supplierId: 's1', supplierName: 'CarbonCure Technologies',
  },
  {
    id: '2', name: 'Nucor Econoweb Steel Decking', manufacturer: 'Nucor Building Systems',
    category: 'Steel', subcategory: 'Structural Decking', description: 'High-recycled-content steel decking with 93% post-consumer recycled content.',
    gwpValue: 1.2, gwpUnit: 'kgCO₂e/kg', sustainabilityScore: 92, certifications: ['EPD', 'GreenGuard', 'LEED'],
    hasEpd: true, verified: true, priceUnit: 'per SF', leadTimeDays: 14,
    supplierId: 's2', supplierName: 'Nucor Building Systems',
  },
  {
    id: '3', name: 'Rockwool Safe\'n\'Sound Insulation', manufacturer: 'Rockwool',
    category: 'Insulation', subcategory: 'Mineral Wool', description: 'Stone wool insulation with fire resistance and verified low GWP from recycled basalt.',
    gwpValue: 1.08, gwpUnit: 'kgCO₂e/kg', sustainabilityScore: 79, certifications: ['EPD', 'GreenGuard Gold', 'FSC'],
    hasEpd: true, verified: true, priceUnit: 'per bag', leadTimeDays: 5,
    supplierId: 's3', supplierName: 'Rockwool North America',
  },
  {
    id: '4', name: 'Vitro Solarban 90 Glass', manufacturer: 'Vitro Architectural Glass',
    category: 'Glass', subcategory: 'Low-E Glazing', description: 'High-performance solar control low-e glass optimized for LEED daylighting credits.',
    gwpValue: 15.3, gwpUnit: 'kgCO₂e/m²', sustainabilityScore: 85, certifications: ['EPD', 'LEED'],
    hasEpd: true, verified: false, priceUnit: 'per SF', leadTimeDays: 21,
    supplierId: 's4', supplierName: 'Vitro Architectural Glass',
  },
  {
    id: '5', name: 'LP SolidStart LSL Timber', manufacturer: 'LP Building Solutions',
    category: 'Timber', subcategory: 'Engineered Lumber', description: 'Laminated strand lumber from fast-growth sustainably harvested species. FSC certified.',
    gwpValue: -120, gwpUnit: 'kgCO₂e/m³', sustainabilityScore: 96, certifications: ['FSC', 'EPD', 'LEED', 'Cradle to Cradle'],
    hasEpd: true, verified: true, priceUnit: 'per LF', leadTimeDays: 7,
    supplierId: 's5', supplierName: 'LP Building Solutions',
  },
  {
    id: '6', name: 'TAMKO Heritage Roofing', manufacturer: 'TAMKO Building Products',
    category: 'Roofing', subcategory: 'Asphalt Shingle', description: 'Cool-roof rated asphalt shingles with recycled content and ENERGY STAR certification.',
    gwpValue: 3.4, gwpUnit: 'kgCO₂e/kg', sustainabilityScore: 71, certifications: ['ENERGY STAR', 'GreenGuard'],
    hasEpd: false, verified: true, priceUnit: 'per square', leadTimeDays: 4,
    supplierId: 's6', supplierName: 'TAMKO Building Products',
  },
  {
    id: '7', name: 'Interface Net Effect Carpet Tile', manufacturer: 'Interface',
    category: 'Flooring', subcategory: 'Carpet Tile', description: 'Carbon negative carpet tile. More carbon stored in product than emitted in manufacturing.',
    gwpValue: -2.1, gwpUnit: 'kgCO₂e/m²', sustainabilityScore: 99, certifications: ['EPD', 'Cradle to Cradle', 'LEED', 'GreenGuard Gold'],
    hasEpd: true, verified: true, priceUnit: 'per SY', leadTimeDays: 10,
    supplierId: 's7', supplierName: 'Interface',
  },
  {
    id: '8', name: 'USG Sheetrock EcoSmart Gypsum', manufacturer: 'USG Corporation',
    category: 'Masonry', subcategory: 'Gypsum Board', description: 'Gypsum wallboard manufactured with 95% recycled content synthetic gypsum.',
    gwpValue: 0.38, gwpUnit: 'kgCO₂e/m²', sustainabilityScore: 82, certifications: ['EPD', 'GreenGuard Gold', 'LEED'],
    hasEpd: true, verified: true, priceUnit: 'per sheet', leadTimeDays: 2,
    supplierId: 's8', supplierName: 'USG Corporation',
  },
]

const CATEGORIES = ['All', 'Concrete', 'Steel', 'Insulation', 'Glass', 'Timber', 'Roofing', 'Flooring', 'Masonry']
const CERTIFICATIONS = ['EPD', 'LEED', 'FSC', 'GreenGuard', 'GreenGuard Gold', 'ENERGY STAR', 'Cradle to Cradle']

// ─── Score color helper ───────────────────────────────────────────────────────

function scoreColor(score: number) {
  if (score >= 90) return 'text-emerald-400'
  if (score >= 75) return 'text-green-400'
  if (score >= 60) return 'text-yellow-400'
  return 'text-orange-400'
}

function scoreBg(score: number) {
  if (score >= 90) return 'bg-emerald-500/10 border-emerald-500/20'
  if (score >= 75) return 'bg-green-500/10 border-green-500/20'
  if (score >= 60) return 'bg-yellow-500/10 border-yellow-500/20'
  return 'bg-orange-500/10 border-orange-500/20'
}

// ─── Material Card ────────────────────────────────────────────────────────────

function MaterialCard({
  material,
  inBasket,
  onAddToQuote,
  onRemoveFromQuote,
}: {
  material: Material
  inBasket: boolean
  onAddToQuote: (m: Material) => void
  onRemoveFromQuote: (id: string) => void
}) {
  return (
    <div className={`group relative bg-[#111] border rounded-xl overflow-hidden transition-all duration-200 hover:border-green-500/30 hover:shadow-lg hover:shadow-green-500/5 ${inBasket ? 'border-green-500/40' : 'border-[#1f1f1f]'}`}>
      {/* Score badge */}
      <div className={`absolute top-3 right-3 flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-bold ${scoreBg(material.sustainabilityScore)} ${scoreColor(material.sustainabilityScore)}`}>
        <Leaf className="w-3 h-3" />
        {material.sustainabilityScore}
      </div>

      {/* In basket indicator */}
      {inBasket && (
        <div className="absolute top-3 left-3 w-5 h-5 rounded-full bg-green-500 flex items-center justify-center">
          <CheckCircle2 className="w-3.5 h-3.5 text-black" />
        </div>
      )}

      <div className="p-5">
        {/* Category + verified */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs text-gray-600 font-medium uppercase tracking-wide">
            {material.category}
          </span>
          {material.verified && (
            <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 text-[10px] px-1.5 py-0">
              ✓ Verified
            </Badge>
          )}
          {material.hasEpd && (
            <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20 text-[10px] px-1.5 py-0">
              EPD
            </Badge>
          )}
        </div>

        {/* Name + manufacturer */}
        <h3 className="text-white font-semibold text-sm leading-snug mb-1 pr-12">
          {material.name}
        </h3>
        <p className="text-gray-500 text-xs mb-3">{material.manufacturer}</p>

        {/* Description */}
        <p className="text-gray-400 text-xs leading-relaxed mb-4 line-clamp-2">
          {material.description}
        </p>

        {/* GWP */}
        <div className="flex items-center gap-1 mb-4">
          <Zap className="w-3 h-3 text-green-400" />
          <span className="text-green-400 text-xs font-mono font-medium">
            {material.gwpValue > 0 ? material.gwpValue : `${material.gwpValue} (carbon negative)`} {material.gwpUnit}
          </span>
        </div>

        {/* Certifications */}
        <div className="flex flex-wrap gap-1 mb-4">
          {material.certifications.slice(0, 3).map((cert) => (
            <span key={cert} className="text-[10px] bg-white/5 text-gray-400 px-1.5 py-0.5 rounded border border-white/10">
              {cert}
            </span>
          ))}
          {material.certifications.length > 3 && (
            <span className="text-[10px] text-gray-600">+{material.certifications.length - 3}</span>
          )}
        </div>

        {/* Lead time + CTA */}
        <div className="flex items-center justify-between pt-3 border-t border-[#1f1f1f]">
          <span className="text-gray-600 text-xs">{material.leadTimeDays}d lead time</span>
          {inBasket ? (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onRemoveFromQuote(material.id)}
              className="text-green-400 hover:text-red-400 hover:bg-red-500/10 text-xs h-7 px-2"
            >
              <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Added
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => onAddToQuote(material)}
              className="bg-green-500 hover:bg-green-400 text-black font-semibold text-xs h-7 px-3"
            >
              Get Quote
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Quote Basket Drawer ──────────────────────────────────────────────────────

function QuoteBasket({
  items,
  onRemove,
  onRequestQuotes,
  onClose,
}: {
  items: QuoteItem[]
  onRemove: (id: string) => void
  onRequestQuotes: () => void
  onClose: () => void
}) {
  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      {/* Drawer */}
      <div className="relative w-full max-w-sm bg-[#0f0f0f] border-l border-[#1f1f1f] flex flex-col h-full shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1f1f1f]">
          <div>
            <h2 className="text-white font-semibold">Quote Basket</h2>
            <p className="text-gray-500 text-xs mt-0.5">{items.length} material{items.length !== 1 ? 's' : ''} — sent to each supplier</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          {items.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="w-8 h-8 text-gray-700 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Your basket is empty</p>
              <p className="text-gray-600 text-xs mt-1">Add materials to request quotes</p>
            </div>
          ) : (
            items.map(({ material }) => (
              <div key={material.id} className="bg-[#151515] border border-[#1f1f1f] rounded-lg p-3 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium leading-snug truncate">{material.name}</p>
                  <p className="text-gray-500 text-xs mt-0.5">{material.manufacturer}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className={`text-xs font-medium ${scoreColor(material.sustainabilityScore)}`}>
                      Score {material.sustainabilityScore}
                    </span>
                    {material.hasEpd && (
                      <span className="text-[10px] bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded">EPD</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => onRemove(material.id)}
                  className="text-gray-600 hover:text-red-400 transition-colors shrink-0 mt-0.5"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="px-5 py-4 border-t border-[#1f1f1f] space-y-3">
          <p className="text-gray-500 text-xs text-center">
            GreenChainz routes each quote to the right supplier automatically.
          </p>
          <Button
            onClick={onRequestQuotes}
            disabled={items.length === 0}
            className="w-full bg-green-500 hover:bg-green-400 text-black font-bold disabled:opacity-40"
          >
            Request {items.length > 0 ? items.length : ''} Quote{items.length !== 1 ? 's' : ''}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// ─── Main Catalog Page ────────────────────────────────────────────────────────

export default function CatalogPage() {
  const router = useRouter()
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [activeCerts, setActiveCerts] = useState<string[]>([])
  const [epdOnly, setEpdOnly] = useState(false)
  const [verifiedOnly, setVerifiedOnly] = useState(false)
  const [sortBy, setSortBy] = useState<'score' | 'carbon' | 'name'>('score')
  const [showFilters, setShowFilters] = useState(false)
  const [basket, setBasket] = useState<QuoteItem[]>([])
  const [showBasket, setShowBasket] = useState(false)

  const addToBasket = useCallback((material: Material) => {
    setBasket((prev) => {
      if (prev.find((i) => i.material.id === material.id)) return prev
      toast.success(`${material.name} added to quote basket`)
      return [...prev, { material }]
    })
  }, [])

  const removeFromBasket = useCallback((id: string) => {
    setBasket((prev) => prev.filter((i) => i.material.id !== id))
  }, [])

  const basketIds = useMemo(() => new Set(basket.map((i) => i.material.id)), [basket])

  const filtered = useMemo(() => {
    let list = MOCK_MATERIALS

    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.manufacturer.toLowerCase().includes(q) ||
          m.category.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q)
      )
    }

    if (activeCategory !== 'All') {
      list = list.filter((m) => m.category === activeCategory)
    }

    if (activeCerts.length > 0) {
      list = list.filter((m) => activeCerts.every((c) => m.certifications.includes(c)))
    }

    if (epdOnly) list = list.filter((m) => m.hasEpd)
    if (verifiedOnly) list = list.filter((m) => m.verified)

    if (sortBy === 'score') list = [...list].sort((a, b) => b.sustainabilityScore - a.sustainabilityScore)
    else if (sortBy === 'carbon') list = [...list].sort((a, b) => a.gwpValue - b.gwpValue)
    else list = [...list].sort((a, b) => a.name.localeCompare(b.name))

    return list
  }, [search, activeCategory, activeCerts, epdOnly, verifiedOnly, sortBy])

  const toggleCert = (cert: string) => {
    setActiveCerts((prev) =>
      prev.includes(cert) ? prev.filter((c) => c !== cert) : [...prev, cert]
    )
  }

  const handleRequestQuotes = () => {
    // Store basket in sessionStorage, route to quote review
    sessionStorage.setItem('quoteBasket', JSON.stringify(basket.map((i) => i.material.id)))
    router.push('/quote/review')
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#0a0a0a]/95 backdrop-blur border-b border-[#1f1f1f]">
        <div className="px-6 py-4 flex items-center gap-3">
          <div className="relative flex-1 max-w-lg">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search materials, manufacturers, certifications..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9"
            />
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters((v) => !v)}
            className={`border-white/10 text-gray-400 hover:text-white h-9 gap-2 ${showFilters ? 'bg-white/10 text-white' : ''}`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Filters
            {(activeCerts.length > 0 || epdOnly || verifiedOnly) && (
              <span className="w-4 h-4 rounded-full bg-green-500 text-black text-[10px] font-bold flex items-center justify-center">
                {activeCerts.length + (epdOnly ? 1 : 0) + (verifiedOnly ? 1 : 0)}
              </span>
            )}
          </Button>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="h-9 bg-white/5 border border-white/10 text-gray-400 text-sm rounded-md px-2 focus:outline-none focus:border-green-500"
          >
            <option value="score">Top Scored</option>
            <option value="carbon">Lowest Carbon</option>
            <option value="name">A–Z</option>
          </select>

          {/* Basket button */}
          <Button
            onClick={() => setShowBasket(true)}
            variant="outline"
            className={`relative h-9 border-white/10 text-gray-400 hover:text-white gap-2 ${basket.length > 0 ? 'border-green-500/40 text-green-400' : ''}`}
          >
            <ShoppingCart className="w-4 h-4" />
            {basket.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-green-500 text-black text-[10px] font-bold flex items-center justify-center">
                {basket.length}
              </span>
            )}
            {basket.length > 0 ? `${basket.length} in basket` : 'Basket'}
          </Button>
        </div>

        {/* Category pills */}
        <div className="px-6 pb-3 flex gap-2 overflow-x-auto scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-green-500 text-black'
                  : 'bg-white/5 text-gray-400 hover:text-white border border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Expanded filters */}
        {showFilters && (
          <div className="px-6 pb-4 border-t border-[#1f1f1f] pt-3 space-y-3">
            <div className="flex flex-wrap gap-2">
              {CERTIFICATIONS.map((cert) => (
                <button
                  key={cert}
                  onClick={() => toggleCert(cert)}
                  className={`px-2.5 py-1 rounded-md text-xs border transition-all ${
                    activeCerts.includes(cert)
                      ? 'bg-green-500/10 border-green-500/40 text-green-400'
                      : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {cert}
                </button>
              ))}
            </div>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={epdOnly}
                  onChange={(e) => setEpdOnly(e.target.checked)}
                  className="accent-green-500"
                />
                <span className="text-gray-400 text-xs">EPD verified only</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={verifiedOnly}
                  onChange={(e) => setVerifiedOnly(e.target.checked)}
                  className="accent-green-500"
                />
                <span className="text-gray-400 text-xs">Verified suppliers only</span>
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Results count */}
      <div className="px-6 pt-5 pb-2 flex items-center justify-between">
        <p className="text-gray-500 text-sm">
          <span className="text-white font-medium">{filtered.length}</span> materials
          {activeCategory !== 'All' && <span> in {activeCategory}</span>}
        </p>
        {basket.length > 0 && (
          <button
            onClick={() => setShowBasket(true)}
            className="text-green-400 text-sm hover:text-green-300 flex items-center gap-1"
          >
            Review {basket.length} quote{basket.length > 1 ? 's' : ''}
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Grid */}
      <div className="px-6 pb-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((material) => (
          <MaterialCard
            key={material.id}
            material={material}
            inBasket={basketIds.has(material.id)}
            onAddToQuote={addToBasket}
            onRemoveFromQuote={removeFromBasket}
          />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center py-20">
            <Search className="w-8 h-8 text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500">No materials match your filters.</p>
            <button
              onClick={() => { setSearch(''); setActiveCategory('All'); setActiveCerts([]); setEpdOnly(false); setVerifiedOnly(false) }}
              className="text-green-400 text-sm mt-2 hover:text-green-300"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>

      {/* Floating basket button (mobile) */}
      {basket.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 sm:hidden">
          <Button
            onClick={() => setShowBasket(true)}
            className="bg-green-500 hover:bg-green-400 text-black font-bold shadow-lg shadow-green-500/20 px-6"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            {basket.length} Quote{basket.length > 1 ? 's' : ''} Ready
          </Button>
        </div>
      )}

      {/* Quote basket drawer */}
      {showBasket && (
        <QuoteBasket
          items={basket}
          onRemove={removeFromBasket}
          onRequestQuotes={handleRequestQuotes}
          onClose={() => setShowBasket(false)}
        />
      )}
    </div>
  )
}
