// app/quote/review/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ArrowLeft,
  Send,
  CheckCircle2,
  Leaf,
  Loader2,
  AlertCircle,
  Building2,
  FileText,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { toast } from 'sonner'

// In real implementation, fetch these from your materials tRPC router by ID
// For now using the same mock shape
interface BasketMaterial {
  id: string
  name: string
  manufacturer: string
  category: string
  sustainabilityScore: number
  hasEpd: boolean
  certifications: string[]
  supplierId: string
  supplierName: string
}

// Mock fetch by IDs — replace with: trpc.materials.getByIds.query({ ids })
async function fetchMaterialsByIds(ids: string[]): Promise<BasketMaterial[]> {
  const ALL_MATERIALS: BasketMaterial[] = [
    { id: '1', name: 'CarbonCure Ready Mix Concrete', manufacturer: 'CarbonCure Technologies', category: 'Concrete', sustainabilityScore: 88, hasEpd: true, certifications: ['EPD', 'LEED'], supplierId: 's1', supplierName: 'CarbonCure Technologies' },
    { id: '2', name: 'Nucor Econoweb Steel Decking', manufacturer: 'Nucor Building Systems', category: 'Steel', sustainabilityScore: 92, hasEpd: true, certifications: ['EPD', 'GreenGuard', 'LEED'], supplierId: 's2', supplierName: 'Nucor Building Systems' },
    { id: '3', name: 'Rockwool Safe\'n\'Sound Insulation', manufacturer: 'Rockwool', category: 'Insulation', sustainabilityScore: 79, hasEpd: true, certifications: ['EPD', 'GreenGuard Gold', 'FSC'], supplierId: 's3', supplierName: 'Rockwool North America' },
    { id: '4', name: 'Vitro Solarban 90 Glass', manufacturer: 'Vitro Architectural Glass', category: 'Glass', sustainabilityScore: 85, hasEpd: true, certifications: ['EPD', 'LEED'], supplierId: 's4', supplierName: 'Vitro Architectural Glass' },
    { id: '5', name: 'LP SolidStart LSL Timber', manufacturer: 'LP Building Solutions', category: 'Timber', sustainabilityScore: 96, hasEpd: true, certifications: ['FSC', 'EPD', 'LEED', 'Cradle to Cradle'], supplierId: 's5', supplierName: 'LP Building Solutions' },
    { id: '6', name: 'TAMKO Heritage Roofing', manufacturer: 'TAMKO Building Products', category: 'Roofing', sustainabilityScore: 71, hasEpd: false, certifications: ['ENERGY STAR', 'GreenGuard'], supplierId: 's6', supplierName: 'TAMKO Building Products' },
    { id: '7', name: 'Interface Net Effect Carpet Tile', manufacturer: 'Interface', category: 'Flooring', sustainabilityScore: 99, hasEpd: true, certifications: ['EPD', 'Cradle to Cradle', 'LEED', 'GreenGuard Gold'], supplierId: 's7', supplierName: 'Interface' },
    { id: '8', name: 'USG Sheetrock EcoSmart Gypsum', manufacturer: 'USG Corporation', category: 'Masonry', sustainabilityScore: 82, hasEpd: true, certifications: ['EPD', 'GreenGuard Gold', 'LEED'], supplierId: 's8', supplierName: 'USG Corporation' },
  ]
  return ALL_MATERIALS.filter((m) => ids.includes(m.id))
}

function scoreColor(score: number) {
  if (score >= 90) return 'text-emerald-400'
  if (score >= 75) return 'text-green-400'
  if (score >= 60) return 'text-yellow-400'
  return 'text-orange-400'
}

export default function QuoteReviewPage() {
  const router = useRouter()
  const [materials, setMaterials] = useState<BasketMaterial[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  // Optional context fields — none are required
  const [projectName, setProjectName] = useState('')
  const [deliveryLocation, setDeliveryLocation] = useState('')
  const [targetDate, setTargetDate] = useState('')
  const [notes, setNotes] = useState('')

  useEffect(() => {
    const stored = sessionStorage.getItem('quoteBasket')
    const ids: string[] = stored ? JSON.parse(stored) : []
    if (ids.length === 0) {
      router.replace('/catalog')
      return
    }
    fetchMaterialsByIds(ids)
      .then(setMaterials)
      .finally(() => setLoading(false))
  }, [router])

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      // TODO: wire to tRPC rfq.createBatch or POST /api/rfq/batch
      // Payload shape:
      // {
      //   materials: materials.map(m => ({ materialId: m.id, supplierId: m.supplierId })),
      //   projectName: projectName || null,
      //   deliveryLocation: deliveryLocation || null,
      //   targetDate: targetDate || null,
      //   notes: notes || null,
      // }
      //
      // The router routes one RFQ per supplierId automatically.
      //
      // PAYWALL CHECK (dormant until launch):
      // const canSubmit = await checkBuyerFeatureAccess(userId, 'rfqSubmission')
      // if (!canSubmit) redirect('/pricing')

      await new Promise((r) => setTimeout(r, 1200)) // Remove when real API is wired
      sessionStorage.removeItem('quoteBasket')
      setSubmitted(true)
    } catch (err) {
      toast.error('Failed to submit quotes. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  // ── Submitted confirmation ────────────────────────────────────────────────
  if (submitted) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center space-y-5">
          <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-2xl font-bold text-white">Quotes Sent</h1>
          <p className="text-gray-400 text-sm leading-relaxed">
            GreenChainz routed your {materials.length} quote request{materials.length > 1 ? 's' : ''} to the right supplier{materials.length > 1 ? 's' : ''}. You'll get responses directly in your RFQ dashboard — typically within 24–48 hours.
          </p>

          <div className="bg-[#111] border border-[#1f1f1f] rounded-xl p-4 text-left space-y-2">
            {materials.map((m) => (
              <div key={m.id} className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
                <span className="text-gray-300 truncate">{m.name}</span>
                <span className="text-gray-600 text-xs ml-auto shrink-0">→ {m.supplierName}</span>
              </div>
            ))}
          </div>

          <div className="flex gap-3">
            <Button asChild className="flex-1 bg-green-500 hover:bg-green-400 text-black font-semibold">
              <Link href="/rfqs">View RFQ Dashboard</Link>
            </Button>
            <Button asChild variant="outline" className="flex-1 border-white/10 text-gray-400 hover:text-white">
              <Link href="/catalog">Browse More</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-green-400" />
      </div>
    )
  }

  // Group by supplier so the architect can see where each quote is going
  const bySupplier = materials.reduce<Record<string, BasketMaterial[]>>((acc, m) => {
    if (!acc[m.supplierId]) acc[m.supplierId] = []
    acc[m.supplierId].push(m)
    return acc
  }, {})

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-10 px-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Back */}
        <Link href="/catalog" className="flex items-center gap-2 text-gray-500 hover:text-white text-sm transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to catalog
        </Link>

        <div>
          <h1 className="text-2xl font-bold text-white mb-1">Review Your Quotes</h1>
          <p className="text-gray-400 text-sm">
            {materials.length} material{materials.length > 1 ? 's' : ''} across {Object.keys(bySupplier).length} supplier{Object.keys(bySupplier).length > 1 ? 's' : ''} — GreenChainz routes each quote automatically.
          </p>
        </div>

        {/* Materials grouped by supplier */}
        <div className="space-y-3">
          <h2 className="text-white text-sm font-semibold uppercase tracking-wide">
            Quote routing
          </h2>
          {Object.entries(bySupplier).map(([supplierId, items]) => (
            <Card key={supplierId} className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4 text-green-400" />
                  <span className="text-white text-sm font-medium">{items[0].supplierName}</span>
                  <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-[10px] ml-auto">
                    {items.length} item{items.length > 1 ? 's' : ''}
                  </Badge>
                </div>
                {items.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 py-1.5 border-t border-[#1a1a1a] first:border-0">
                    <Leaf className={`w-3.5 h-3.5 shrink-0 ${scoreColor(m.sustainabilityScore)}`} />
                    <span className="text-gray-300 text-sm">{m.name}</span>
                    {m.hasEpd && (
                      <span className="text-[10px] bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded ml-auto">EPD</span>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Optional context — none required */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <h2 className="text-white text-sm font-semibold uppercase tracking-wide">
              Project context
            </h2>
            <span className="text-gray-600 text-xs">(optional — helps suppliers respond faster)</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-gray-400 text-xs">Project name</Label>
              <Input
                placeholder="e.g. Midtown Office Tower"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-400 text-xs">Delivery location</Label>
              <Input
                placeholder="e.g. Atlanta, GA"
                value={deliveryLocation}
                onChange={(e) => setDeliveryLocation(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-gray-400 text-xs">Target date needed</Label>
              <Input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="bg-white/5 border-white/10 text-white focus:border-green-500 h-9 text-sm"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-gray-400 text-xs">Additional notes</Label>
            <textarea
              placeholder="Any special requirements, quantities, specs..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full rounded-md bg-white/5 border border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 px-3 py-2 text-sm resize-none"
            />
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center gap-3 pt-2">
          <Button asChild variant="ghost" className="text-gray-400 hover:text-white">
            <Link href="/catalog">
              <ArrowLeft className="w-4 h-4 mr-1" /> Edit basket
            </Link>
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting}
            className="flex-1 bg-green-500 hover:bg-green-400 text-black font-bold h-11"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Sending quotes...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Send {materials.length} Quote Request{materials.length > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </div>

        <p className="text-center text-gray-600 text-xs">
          By submitting, GreenChainz routes each quote to the verified supplier. No spam, no middleman markup.
        </p>
      </div>
    </div>
  )
}
