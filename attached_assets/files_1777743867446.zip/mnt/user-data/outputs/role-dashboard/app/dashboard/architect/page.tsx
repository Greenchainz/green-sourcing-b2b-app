// app/dashboard/architect/page.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
  Search,
  FileText,
  Clock,
  CheckCircle2,
  ArrowRight,
  Leaf,
  Zap,
  LayoutDashboard,
  Plus,
  TrendingDown,
  AlertCircle,
  Loader2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface ArchitectDashboardData {
  name: string
  activeRfqs: number
  pendingResponses: number
  carbonSavedKg: number
  recentRfqs: {
    id: string
    materialName: string
    supplierCount: number
    status: 'pending' | 'responded' | 'closed'
    createdAt: string
  }[]
  recommendedMaterials: {
    id: string
    name: string
    manufacturer: string
    category: string
    sustainabilityScore: number
    imageUrl?: string
  }[]
}

const STATUS_CONFIG = {
  pending: { label: 'Awaiting response', color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' },
  responded: { label: 'Response received', color: 'bg-green-500/10 text-green-400 border-green-500/20' },
  closed: { label: 'Closed', color: 'bg-white/5 text-gray-500 border-white/10' },
}

// Mock — replace with tRPC architect.getDashboard.query()
const MOCK_DATA: ArchitectDashboardData = {
  name: 'Alex',
  activeRfqs: 3,
  pendingResponses: 7,
  carbonSavedKg: 1240,
  recentRfqs: [
    { id: 'rfq-1', materialName: 'Low-Carbon Concrete', supplierCount: 3, status: 'responded', createdAt: '2 hours ago' },
    { id: 'rfq-2', materialName: 'Recycled Steel Framing', supplierCount: 2, status: 'pending', createdAt: '1 day ago' },
    { id: 'rfq-3', materialName: 'FSC Timber Panels', supplierCount: 4, status: 'responded', createdAt: '3 days ago' },
  ],
  recommendedMaterials: [
    { id: '1', name: 'Interface Net Effect Carpet Tile', manufacturer: 'Interface', category: 'Flooring', sustainabilityScore: 99 },
    { id: '5', name: 'LP SolidStart LSL Timber', manufacturer: 'LP Building Solutions', category: 'Timber', sustainabilityScore: 96 },
    { id: '2', name: 'Nucor Econoweb Steel Decking', manufacturer: 'Nucor', category: 'Steel', sustainabilityScore: 92 },
  ],
}

function scoreColor(s: number) {
  if (s >= 90) return 'text-emerald-400'
  if (s >= 75) return 'text-green-400'
  return 'text-yellow-400'
}

export default function ArchitectDashboardPage() {
  const [data, setData] = useState<ArchitectDashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // TODO: replace with real tRPC call
    // trpc.architect.getDashboard.query()
    setTimeout(() => { setData(MOCK_DATA); setLoading(false) }, 400)
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-green-400" />
      </div>
    )
  }

  if (!data) return null

  return (
    <div className="p-6 sm:p-8 max-w-5xl space-y-8">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">
            Good to see you{data.name ? `, ${data.name.split(' ')[0]}` : ''}.
          </h1>
          <p className="text-gray-400 text-sm mt-1">Here's what's happening with your material sourcing.</p>
        </div>
        <Button asChild className="bg-green-500 hover:bg-green-400 text-black font-bold gap-2">
          <Link href="/catalog">
            <Search className="w-4 h-4" /> Find Materials
          </Link>
        </Button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-[#111] border-[#1f1f1f]">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-500 text-xs uppercase tracking-wide">Active RFQs</span>
              <FileText className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-3xl font-black text-white">{data.activeRfqs}</div>
            <Link href="/rfqs" className="text-green-400 text-xs mt-1 flex items-center gap-1 hover:text-green-300">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-[#111] border-[#1f1f1f]">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-500 text-xs uppercase tracking-wide">Responses waiting</span>
              <Clock className="w-4 h-4 text-yellow-400" />
            </div>
            <div className="text-3xl font-black text-white">{data.pendingResponses}</div>
            <p className="text-gray-600 text-xs mt-1">supplier responses</p>
          </CardContent>
        </Card>

        <Card className="bg-[#111] border-[#1f1f1f]">
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-500 text-xs uppercase tracking-wide">Carbon saved</span>
              <TrendingDown className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-black text-emerald-400">
              {data.carbonSavedKg >= 1000
                ? `${(data.carbonSavedKg / 1000).toFixed(1)}t`
                : `${data.carbonSavedKg}kg`}
            </div>
            <p className="text-gray-600 text-xs mt-1">vs. conventional specs</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* Recent RFQs */}
        <div className="lg:col-span-3 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-white font-semibold text-sm uppercase tracking-wide">Recent RFQs</h2>
            <Link href="/rfqs" className="text-green-400 text-xs hover:text-green-300 flex items-center gap-1">
              All RFQs <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {data.recentRfqs.length === 0 ? (
            <Card className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="py-10 text-center">
                <FileText className="w-7 h-7 text-gray-700 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">No RFQs yet.</p>
                <Link href="/catalog" className="text-green-400 text-sm mt-1 inline-block hover:text-green-300">
                  Browse materials to get started →
                </Link>
              </CardContent>
            </Card>
          ) : (
            data.recentRfqs.map((rfq) => (
              <Link key={rfq.id} href={`/rfqs/${rfq.id}`}>
                <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/25 transition-all cursor-pointer">
                  <CardContent className="py-3.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium truncate">{rfq.materialName}</p>
                      <p className="text-gray-500 text-xs mt-0.5">
                        {rfq.supplierCount} supplier{rfq.supplierCount > 1 ? 's' : ''} · {rfq.createdAt}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className={`text-[10px] px-2 py-0.5 border ${STATUS_CONFIG[rfq.status].color}`}>
                        {STATUS_CONFIG[rfq.status].label}
                      </Badge>
                      <ArrowRight className="w-3.5 h-3.5 text-gray-600" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))
          )}

          <Button asChild variant="outline" className="w-full border-white/10 text-gray-400 hover:text-white gap-2">
            <Link href="/catalog">
              <Plus className="w-4 h-4" /> New Quote Request
            </Link>
          </Button>
        </div>

        {/* Recommended materials */}
        <div className="lg:col-span-2 space-y-3">
          <h2 className="text-white font-semibold text-sm uppercase tracking-wide">Top Rated Materials</h2>
          {data.recommendedMaterials.map((m) => (
            <Link key={m.id} href={`/catalog?highlight=${m.id}`}>
              <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/25 transition-all cursor-pointer">
                <CardContent className="py-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-900/30 to-[#0a0a0a] flex items-center justify-center shrink-0 border border-green-900/20">
                    <Leaf className="w-4 h-4 text-green-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs font-medium truncate">{m.name}</p>
                    <p className="text-gray-600 text-[10px]">{m.manufacturer}</p>
                  </div>
                  <span className={`text-sm font-black shrink-0 ${scoreColor(m.sustainabilityScore)}`}>
                    {m.sustainabilityScore}
                  </span>
                </CardContent>
              </Card>
            </Link>
          ))}
          <Button asChild variant="ghost" className="w-full text-gray-400 hover:text-white text-xs gap-1">
            <Link href="/catalog">
              Browse full catalog <ArrowRight className="w-3 h-3" />
            </Link>
          </Button>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Browse Catalog', icon: Search, href: '/catalog', desc: 'Find verified sustainable materials' },
          { label: 'My RFQs', icon: FileText, href: '/rfqs', desc: 'Track quotes and supplier responses' },
          { label: 'Carbon Compare', icon: Zap, href: '/tools', desc: 'Compare embodied carbon side by side' },
        ].map(({ label, icon: Icon, href, desc }) => (
          <Link key={label} href={href}>
            <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/25 transition-all cursor-pointer h-full">
              <CardContent className="py-4 flex flex-col gap-2">
                <Icon className="w-5 h-5 text-green-400" />
                <p className="text-white text-sm font-semibold">{label}</p>
                <p className="text-gray-500 text-xs leading-snug">{desc}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
