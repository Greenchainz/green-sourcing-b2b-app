// app/dashboard/page.tsx
/**
 * Role-aware dashboard entry point.
 *
 * This is a SERVER component — it fetches the user role from /api/auth/me
 * on the server side and redirects before sending anything to the browser.
 * No flash, no loading state, no client-side redirect flicker.
 *
 * Role routing:
 *   admin    → /dashboard/admin
 *   supplier → /supplier          (supplier portal)
 *   architect/buyer → /dashboard/architect
 *   no profile → /dashboard/architect with onboarding CTA
 */

import { redirect } from 'next/navigation'
import { headers } from 'next/headers'

interface AuthUser {
  id: string
  email: string
  name: string
  roles: string[]
  isAdmin: boolean
  isSupplier: boolean
  isArchitect: boolean
}

async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    // In the App Router server component, we forward the incoming request
    // headers so Easy Auth cookies/headers pass through to our Express API.
    const headersList = headers()
    const cookie = headersList.get('cookie') ?? ''
    const easyAuthId = headersList.get('x-ms-client-principal-id') ?? ''
    const easyAuthName = headersList.get('x-ms-client-principal-name') ?? ''
    const easyAuthPrincipal = headersList.get('x-ms-client-principal') ?? ''

    // Call our own /api/auth/me — works in both dev (JWT cookie) and prod (Easy Auth)
    const apiBase = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001'
    const res = await fetch(`${apiBase}/api/auth/me`, {
      headers: {
        cookie,
        ...(easyAuthId && { 'x-ms-client-principal-id': easyAuthId }),
        ...(easyAuthName && { 'x-ms-client-principal-name': easyAuthName }),
        ...(easyAuthPrincipal && { 'x-ms-client-principal': easyAuthPrincipal }),
      },
      cache: 'no-store',
    })

    if (!res.ok) return null
    const data = await res.json()
    return data.user ?? null
  } catch {
    return null
  }
}

export default async function DashboardPage() {
  const user = await getCurrentUser()

  // Not authenticated — send to login
  if (!user) {
    redirect('/login?callbackUrl=/dashboard')
  }

  // Route by role
  if (user.isAdmin) {
    redirect('/dashboard/admin')
  }

  if (user.isSupplier) {
    redirect('/supplier')
  }

  // Default: architect/buyer
  redirect('/dashboard/architect')
}
