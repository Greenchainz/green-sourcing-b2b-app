// app/dashboard/admin/page.tsx
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
  Users,
  Package,
  FileText,
  Star,
  TrendingUp,
  ArrowRight,
  Loader2,
  Shield,
  Zap,
  AlertTriangle,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

interface AdminStats {
  totalSuppliers: number
  verifiedSuppliers: number
  totalArchitects: number
  totalMaterials: number
  activeRfqs: number
  pendingVerifications: number
  featuredPlacements: number
  newSignupsToday: number
}

// Mock — replace with tRPC admin.getStats.query()
const MOCK_STATS: AdminStats = {
  totalSuppliers: 3,
  verifiedSuppliers: 1,
  totalArchitects: 7,
  totalMaterials: 86,
  activeRfqs: 4,
  pendingVerifications: 2,
  featuredPlacements: 0,
  newSignupsToday: 2,
}

const ADMIN_ACTIONS = [
  { label: 'Manage Featured Placements', href: '/admin/featured', icon: Star, desc: 'Set paid featured slots' },
  { label: 'Scrape Material Images', href: '/admin/scrape-images', icon: Package, desc: 'Run Playwright image scraper' },
  { label: 'Verify Suppliers', href: '/admin/suppliers', icon: Shield, desc: `${MOCK_STATS.pendingVerifications} pending` },
  { label: 'View All RFQs', href: '/admin/rfqs', icon: FileText, desc: 'Monitor platform RFQ activity' },
  { label: 'User Management', href: '/admin/users', icon: Users, desc: 'Manage roles and access' },
  { label: 'Platform Analytics', href: '/admin/analytics', icon: TrendingUp, desc: 'Traffic, conversion, retention' },
]

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // TODO: replace with trpc.admin.getStats.query()
    setTimeout(() => { setStats(MOCK_STATS); setLoading(false) }, 300)
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-green-400" />
      </div>
    )
  }

  if (!stats) return null

  const foundingProgress = Math.round((stats.verifiedSuppliers / 50) * 100)

  return (
    <div className="p-6 sm:p-8 max-w-5xl space-y-8">

      <div>
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="text-gray-400 text-sm mt-1">Platform overview — GreenChainz</p>
      </div>

      {/* Founding 50 progress */}
      <Card className="bg-gradient-to-br from-yellow-500/10 to-transparent border-yellow-500/20">
        <CardContent className="py-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-white font-semibold text-sm">Founding 50 Progress</span>
            </div>
            <span className="text-yellow-400 font-bold text-sm">
              {stats.verifiedSuppliers} / 50
            </span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-yellow-400 rounded-full transition-all"
              style={{ width: `${foundingProgress}%` }}
            />
          </div>
          <p className="text-gray-500 text-xs mt-2">
            {50 - stats.verifiedSuppliers} spots remaining before program closes
          </p>
        </CardContent>
      </Card>

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Suppliers', value: stats.totalSuppliers, sub: `${stats.verifiedSuppliers} verified`, icon: Package, color: 'text-green-400' },
          { label: 'Architects', value: stats.totalArchitects, sub: `${stats.newSignupsToday} today`, icon: Users, color: 'text-blue-400' },
          { label: 'Materials', value: stats.totalMaterials, sub: 'in catalog', icon: Zap, color: 'text-purple-400' },
          { label: 'Active RFQs', value: stats.activeRfqs, sub: 'in progress', icon: FileText, color: 'text-yellow-400' },
        ].map(({ label, value, sub, icon: Icon, color }) => (
          <Card key={label} className="bg-[#111] border-[#1f1f1f]">
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-500 text-xs uppercase tracking-wide">{label}</span>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div className="text-2xl font-black text-white">{value}</div>
              <p className="text-gray-600 text-xs mt-0.5">{sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pending actions alert */}
      {stats.pendingVerifications > 0 && (
        <Card className="bg-yellow-500/5 border-yellow-500/20">
          <CardContent className="py-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0" />
              <p className="text-yellow-300 text-sm">
                <span className="font-semibold">{stats.pendingVerifications} supplier{stats.pendingVerifications > 1 ? 's' : ''}</span> waiting for verification
              </p>
            </div>
            <Button asChild size="sm" variant="outline" className="border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/10 shrink-0">
              <Link href="/admin/suppliers">Review now</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Quick admin actions */}
      <div>
        <h2 className="text-white font-semibold text-sm uppercase tracking-wide mb-3">Admin Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {ADMIN_ACTIONS.map(({ label, href, icon: Icon, desc }) => (
            <Link key={label} href={href}>
              <Card className="bg-[#111] border-[#1f1f1f] hover:border-green-500/25 transition-all cursor-pointer h-full">
                <CardContent className="py-4 flex flex-col gap-2">
                  <Icon className="w-5 h-5 text-green-400" />
                  <p className="text-white text-sm font-semibold leading-snug">{label}</p>
                  <p className="text-gray-500 text-xs">{desc}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
