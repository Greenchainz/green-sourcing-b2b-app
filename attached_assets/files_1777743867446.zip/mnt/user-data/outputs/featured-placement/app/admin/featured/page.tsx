// app/admin/featured/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { Star, Loader2, AlertCircle, CheckCircle2, X, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { toast } from 'sonner'

interface FeaturedPlacement {
  id: number
  name?: string
  companyName?: string
  category?: string
  featuredUntil?: string | null
}

interface Placements {
  materials: FeaturedPlacement[]
  suppliers: FeaturedPlacement[]
}

export default function AdminFeaturedPage() {
  const [placements, setPlacements] = useState<Placements>({ materials: [], suppliers: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Add form state
  const [addType, setAddType] = useState<'material' | 'supplier'>('material')
  const [addId, setAddId] = useState('')
  const [addDays, setAddDays] = useState('30')
  const [adding, setAdding] = useState(false)

  const fetchPlacements = async () => {
    try {
      const res = await fetch('/api/trpc/featured.listFeaturedPlacements', {
        credentials: 'include',
      })
      if (!res.ok) throw new Error(`Error ${res.status}`)
      const data = await res.json()
      setPlacements(data.result?.data ?? { materials: [], suppliers: [] })
    } catch (err) {
      setError('Failed to load featured placements')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchPlacements() }, [])

  const addFeatured = async () => {
    const id = parseInt(addId, 10)
    if (isNaN(id) || id < 1) {
      toast.error('Enter a valid ID')
      return
    }

    const days = parseInt(addDays, 10)
    const featuredUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString()
    setAdding(true)

    try {
      const endpoint = addType === 'material'
        ? '/api/trpc/featured.setFeaturedMaterial'
        : '/api/trpc/featured.setFeaturedSupplier'

      const body = addType === 'material'
        ? { materialId: id, featured: true, featuredUntil }
        : { supplierId: id, featured: true, featuredUntil }

      const res = await fetch(endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (!res.ok) throw new Error(`Error ${res.status}`)
      toast.success(`${addType === 'material' ? 'Material' : 'Supplier'} ${id} featured for ${days} days`)
      setAddId('')
      await fetchPlacements()
    } catch (err) {
      toast.error('Failed to set featured placement')
    } finally {
      setAdding(false)
    }
  }

  const removeFeatured = async (type: 'material' | 'supplier', id: number) => {
    try {
      const endpoint = type === 'material'
        ? '/api/trpc/featured.setFeaturedMaterial'
        : '/api/trpc/featured.setFeaturedSupplier'

      const body = type === 'material'
        ? { materialId: id, featured: false }
        : { supplierId: id, featured: false }

      const res = await fetch(endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (!res.ok) throw new Error()
      toast.success('Removed from featured')
      await fetchPlacements()
    } catch {
      toast.error('Failed to remove featured placement')
    }
  }

  const daysLeft = (until?: string | null) => {
    if (!until) return '∞'
    const diff = new Date(until).getTime() - Date.now()
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
    return days > 0 ? `${days}d left` : 'Expired'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-green-400" />
      </div>
    )
  }

  return (
    <div className="p-8 max-w-3xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white mb-1 flex items-center gap-2">
          <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
          Featured Placements
        </h1>
        <p className="text-gray-400 text-sm">
          Featured materials and suppliers appear at the top of the catalog. Charge $99–$499/mo per slot.
        </p>
      </div>

      {error && (
        <Alert className="border-red-500/20 bg-red-500/10">
          <AlertCircle className="w-4 h-4 text-red-400" />
          <AlertDescription className="text-red-300">{error}</AlertDescription>
        </Alert>
      )}

      {/* Add featured */}
      <Card className="bg-[#111] border-[#1f1f1f]">
        <CardHeader>
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Plus className="w-4 h-4 text-green-400" /> Add Featured Placement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Type toggle */}
          <div className="flex gap-2">
            {(['material', 'supplier'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setAddType(t)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all border ${
                  addType === t
                    ? 'bg-green-500/10 border-green-500/40 text-green-400'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                }`}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-gray-400 text-xs">
                {addType === 'material' ? 'Material' : 'Supplier'} ID
              </Label>
              <Input
                placeholder="e.g. 42"
                value={addId}
                onChange={(e) => setAddId(e.target.value)}
                className="bg-white/5 border-white/10 text-white h-9 text-sm focus:border-green-500"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-400 text-xs">Duration (days)</Label>
              <Input
                type="number"
                min="1"
                max="365"
                value={addDays}
                onChange={(e) => setAddDays(e.target.value)}
                className="bg-white/5 border-white/10 text-white h-9 text-sm focus:border-green-500"
              />
            </div>
          </div>

          <Button
            onClick={addFeatured}
            disabled={adding || !addId}
            className="bg-green-500 hover:bg-green-400 text-black font-semibold"
          >
            {adding ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Star className="w-4 h-4 mr-2" />}
            Feature {addType === 'material' ? 'Material' : 'Supplier'}
          </Button>
        </CardContent>
      </Card>

      {/* Active featured materials */}
      <div className="space-y-3">
        <h2 className="text-white font-semibold text-sm uppercase tracking-wide">
          Featured Materials ({placements.materials.length})
        </h2>
        {placements.materials.length === 0 ? (
          <p className="text-gray-600 text-sm">No featured materials yet.</p>
        ) : (
          placements.materials.map((m) => (
            <Card key={m.id} className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="py-3 flex items-center justify-between">
                <div>
                  <p className="text-white text-sm font-medium">{m.name ?? `Material #${m.id}`}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {m.category && (
                      <span className="text-gray-500 text-xs">{m.category}</span>
                    )}
                    <Badge className={`text-[10px] px-1.5 py-0 ${
                      daysLeft(m.featuredUntil) === 'Expired'
                        ? 'bg-red-500/10 text-red-400 border-red-500/20'
                        : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                    }`}>
                      {daysLeft(m.featuredUntil)}
                    </Badge>
                  </div>
                </div>
                <button
                  onClick={() => removeFeatured('material', m.id)}
                  className="text-gray-600 hover:text-red-400 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Active featured suppliers */}
      <div className="space-y-3">
        <h2 className="text-white font-semibold text-sm uppercase tracking-wide">
          Featured Suppliers ({placements.suppliers.length})
        </h2>
        {placements.suppliers.length === 0 ? (
          <p className="text-gray-600 text-sm">No featured suppliers yet.</p>
        ) : (
          placements.suppliers.map((s) => (
            <Card key={s.id} className="bg-[#111] border-[#1f1f1f]">
              <CardContent className="py-3 flex items-center justify-between">
                <div>
                  <p className="text-white text-sm font-medium">{s.companyName ?? `Supplier #${s.id}`}</p>
                  <Badge className={`text-[10px] px-1.5 py-0 mt-1 ${
                    daysLeft(s.featuredUntil) === 'Expired'
                      ? 'bg-red-500/10 text-red-400 border-red-500/20'
                      : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                  }`}>
                    {daysLeft(s.featuredUntil)}
                  </Badge>
                </div>
                <button
                  onClick={() => removeFeatured('supplier', s.id)}
                  className="text-gray-600 hover:text-red-400 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
