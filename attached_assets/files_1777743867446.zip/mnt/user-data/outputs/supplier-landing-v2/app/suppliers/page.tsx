// app/suppliers/page.tsx
/**
 * Supplier landing page — "Claim Your Profile" angle.
 *
 * Hook: Your products are already here. Search for your company.
 * Pitch: Claim + upgrade to white-glove for $750. Or DIY free.
 * Lead: Request form → emails Jerit directly.
 */
'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import {
  Search,
  CheckCircle2,
  ArrowRight,
  Zap,
  Shield,
  TrendingUp,
  Users,
  Clock,
  ChevronDown,
  Loader2,
  AlertCircle,
  Star,
  Leaf,
  Lock,
  Eye,
  ImageOff,
  FileX,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'

// ─── Mock search results (replace with real tRPC call) ────────────────────────
// In production: trpc.materials.searchByManufacturer.query({ q })
// Returns: array of { manufacturer, productCount, hasImages, hasEpds, isVerified, isClaimed }

interface SupplierSearchResult {
  manufacturer: string
  productCount: number
  hasImages: boolean
  hasEpds: boolean
  isVerified: boolean
  isClaimed: boolean
  categories: string[]
}

const MOCK_RESULTS: SupplierSearchResult[] = [
  { manufacturer: 'CarbonCure Technologies', productCount: 4, hasImages: false, hasEpds: true, isVerified: false, isClaimed: false, categories: ['Concrete'] },
  { manufacturer: 'Nucor Building Systems', productCount: 12, hasImages: false, hasEpds: false, isVerified: false, isClaimed: false, categories: ['Steel', 'Structural'] },
  { manufacturer: 'Rockwool North America', productCount: 8, hasImages: true, hasEpds: true, isVerified: true, isClaimed: true, categories: ['Insulation'] },
  { manufacturer: 'LP Building Solutions', productCount: 6, hasImages: false, hasEpds: false, isVerified: false, isClaimed: false, categories: ['Timber', 'Engineered Wood'] },
  { manufacturer: 'Interface', productCount: 22, hasImages: false, hasEpds: true, isVerified: false, isClaimed: false, categories: ['Flooring'] },
  { manufacturer: 'USG Corporation', productCount: 18, hasImages: false, hasEpds: false, isVerified: false, isClaimed: false, categories: ['Masonry', 'Gypsum'] },
  { manufacturer: 'TAMKO Building Products', productCount: 9, hasImages: false, hasEpds: false, isVerified: false, isClaimed: false, categories: ['Roofing'] },
  { manufacturer: 'Vitro Architectural Glass', productCount: 7, hasImages: false, hasEpds: true, isVerified: false, isClaimed: false, categories: ['Glass', 'Glazing'] },
]

async function searchManufacturers(q: string): Promise<SupplierSearchResult[]> {
  // TODO: replace with real API call
  // const res = await fetch(`/api/trpc/materials.searchByManufacturer?input=${encodeURIComponent(JSON.stringify({ q }))}`, { credentials: 'include' })
  await new Promise((r) => setTimeout(r, 300))
  if (!q.trim()) return []
  return MOCK_RESULTS.filter((r) =>
    r.manufacturer.toLowerCase().includes(q.toLowerCase())
  )
}

// ─── Profile health indicators ────────────────────────────────────────────────

function ProfileHealthBadge({ result }: { result: SupplierSearchResult }) {
  const issues = []
  if (!result.hasImages) issues.push('No product photos')
  if (!result.hasEpds) issues.push('No EPDs linked')
  if (!result.isVerified) issues.push('Unverified')

  if (result.isClaimed && result.isVerified) {
    return (
      <span className="flex items-center gap-1 text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full font-medium">
        <CheckCircle2 className="w-2.5 h-2.5" /> Claimed & Verified
      </span>
    )
  }

  return (
    <span className="flex items-center gap-1 text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/20 px-2 py-0.5 rounded-full font-medium">
      <AlertCircle className="w-2.5 h-2.5" /> {issues.length} issue{issues.length > 1 ? 's' : ''}
    </span>
  )
}

// ─── Live search component ────────────────────────────────────────────────────

function CompanySearch({ onSelect }: { onSelect: (name: string) => void }) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SupplierSearchResult[]>([])
  const [searching, setSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!query.trim()) { setResults([]); return }
    setSearching(true)
    const timer = setTimeout(async () => {
      const r = await searchManufacturers(query)
      setResults(r)
      setSearching(false)
      setShowResults(true)
    }, 300)
    return () => clearTimeout(timer)
  }, [query])

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setShowResults(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  return (
    <div ref={ref} className="relative max-w-xl mx-auto">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
        {searching && (
          <Loader2 className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 animate-spin" />
        )}
        <input
          type="text"
          placeholder="Search your company name..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => results.length > 0 && setShowResults(true)}
          className="w-full h-14 pl-12 pr-12 bg-white/5 border-2 border-white/10 focus:border-green-500 rounded-xl text-white placeholder:text-gray-500 text-base outline-none transition-colors"
        />
      </div>

      {/* Results dropdown */}
      {showResults && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#111] border border-[#1f1f1f] rounded-xl overflow-hidden shadow-2xl z-50">
          {results.map((r) => (
            <button
              key={r.manufacturer}
              onClick={() => {
                onSelect(r.manufacturer)
                setQuery(r.manufacturer)
                setShowResults(false)
              }}
              className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-white/5 transition-colors border-b border-white/5 last:border-0 text-left"
            >
              <div>
                <p className="text-white text-sm font-medium">{r.manufacturer}</p>
                <p className="text-gray-500 text-xs mt-0.5">
                  {r.productCount} products · {r.categories.join(', ')}
                </p>
              </div>
              <div className="flex items-center gap-2 ml-3">
                <ProfileHealthBadge result={r} />
                <ArrowRight className="w-3.5 h-3.5 text-gray-600" />
              </div>
            </button>
          ))}
          <div className="px-4 py-2.5 bg-white/[0.02] border-t border-white/5">
            <p className="text-gray-600 text-xs">
              Don't see your company?{' '}
              <a href="#request" className="text-green-500 hover:text-green-400">
                Request to be added →
              </a>
            </p>
          </div>
        </div>
      )}

      {/* No results */}
      {showResults && query && !searching && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#111] border border-[#1f1f1f] rounded-xl p-5 text-center shadow-2xl z-50">
          <p className="text-gray-400 text-sm">No listings found for "{query}"</p>
          <a href="#request" className="text-green-400 text-sm hover:text-green-300 mt-1 inline-block">
            Request to add your company →
          </a>
        </div>
      )}
    </div>
  )
}

// ─── Profile preview card ─────────────────────────────────────────────────────

function ProfilePreview({ companyName }: { companyName: string }) {
  const result = MOCK_RESULTS.find(
    (r) => r.manufacturer.toLowerCase() === companyName.toLowerCase()
  )

  if (!result) return null

  const issues = [
    !result.hasImages && { icon: ImageOff, label: 'No product photos', fix: 'We source or photograph your products' },
    !result.hasEpds && { icon: FileX, label: 'EPDs not linked', fix: 'We upload and index all your EPDs' },
    !result.isVerified && { icon: Shield, label: 'Profile unverified', fix: 'We complete full verification in 48hrs' },
  ].filter(Boolean) as { icon: typeof ImageOff; label: string; fix: string }[]

  if (result.isClaimed && result.isVerified) {
    return (
      <div className="max-w-xl mx-auto mt-6 bg-green-500/10 border border-green-500/20 rounded-xl p-5 text-center">
        <CheckCircle2 className="w-6 h-6 text-green-400 mx-auto mb-2" />
        <p className="text-white font-semibold">This profile is already claimed and verified.</p>
        <p className="text-gray-400 text-sm mt-1">Looks like someone from your team is ahead of you.</p>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto mt-6 bg-[#0f0f0f] border border-orange-500/25 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
        <div>
          <p className="text-white font-semibold text-sm">{result.manufacturer}</p>
          <p className="text-gray-500 text-xs mt-0.5">
            {result.productCount} products in catalog · {result.categories.join(', ')}
          </p>
        </div>
        <div className="flex items-center gap-1.5 bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-semibold px-2.5 py-1 rounded-full">
          <AlertCircle className="w-3 h-3" /> Unclaimed
        </div>
      </div>

      {/* Issues */}
      <div className="divide-y divide-white/5">
        {issues.map(({ icon: Icon, label, fix }) => (
          <div key={label} className="flex items-center gap-4 px-5 py-3.5">
            <div className="w-8 h-8 rounded-lg bg-orange-500/10 flex items-center justify-center shrink-0">
              <Icon className="w-4 h-4 text-orange-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-orange-300 text-sm font-medium">{label}</p>
              <p className="text-gray-500 text-xs">{fix}</p>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-gray-600 shrink-0" />
          </div>
        ))}
      </div>

      {/* CTA */}
      <div className="px-5 py-4 bg-white/[0.02] flex items-center justify-between gap-3">
        <p className="text-gray-400 text-xs leading-relaxed">
          Architects are seeing this bare listing right now. Founding members get it fixed free.
        </p>
        <a href="#request" className="shrink-0">
          <Button size="sm" className="bg-green-500 hover:bg-green-400 text-black font-bold text-xs whitespace-nowrap">
            Claim Free <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        </a>
      </div>
    </div>
  )
}

// ─── Before / After comparison ────────────────────────────────────────────────

function BeforeAfter() {
  return (
    <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
      {/* Before */}
      <div className="bg-[#0f0f0f] border border-red-500/15 rounded-xl overflow-hidden">
        <div className="bg-red-500/10 border-b border-red-500/15 px-4 py-2 flex items-center gap-2">
          <AlertCircle className="w-3.5 h-3.5 text-red-400" />
          <span className="text-red-400 text-xs font-bold uppercase tracking-wide">Unclaimed listing</span>
        </div>
        <div className="p-4 space-y-3">
          <div className="h-24 bg-white/5 rounded-lg flex items-center justify-center">
            <ImageOff className="w-6 h-6 text-gray-700" />
          </div>
          <div className="space-y-1.5">
            <div className="h-3 bg-white/10 rounded w-3/4" />
            <div className="h-2.5 bg-white/5 rounded w-1/2" />
          </div>
          <div className="flex gap-1.5">
            <div className="h-5 bg-white/5 rounded px-2 w-16 border border-white/10" />
            <div className="h-5 bg-white/5 rounded px-2 w-12 border border-white/10" />
          </div>
          <div className="space-y-1">
            <div className="h-2 bg-white/5 rounded w-full" />
            <div className="h-2 bg-white/5 rounded w-5/6" />
            <div className="h-2 bg-white/5 rounded w-4/6" />
          </div>
          <div className="text-[10px] text-gray-600 italic">No description. No certs. No photos.</div>
        </div>
      </div>

      {/* After */}
      <div className="bg-[#0f0f0f] border border-green-500/25 rounded-xl overflow-hidden">
        <div className="bg-green-500/10 border-b border-green-500/15 px-4 py-2 flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-green-400" />
          <span className="text-green-400 text-xs font-bold uppercase tracking-wide">Verified profile</span>
        </div>
        <div className="p-4 space-y-3">
          <div className="h-24 bg-gradient-to-br from-green-900/20 to-[#0a0f0a] rounded-lg flex items-center justify-center border border-green-500/10">
            <Leaf className="w-8 h-8 text-green-700" />
          </div>
          <div className="space-y-1.5">
            <div className="h-3 bg-white/20 rounded w-3/4" />
            <div className="h-2.5 bg-white/10 rounded w-1/2" />
          </div>
          <div className="flex gap-1.5">
            <div className="h-5 bg-purple-500/20 rounded px-2 w-10 border border-purple-500/30 text-[8px] text-purple-400 flex items-center">EPD</div>
            <div className="h-5 bg-blue-500/20 rounded px-2 w-14 border border-blue-500/30 text-[8px] text-blue-400 flex items-center">LEED</div>
            <div className="h-5 bg-green-500/20 rounded px-2 w-10 border border-green-500/30 text-[8px] text-green-400 flex items-center">FSC</div>
          </div>
          <div className="space-y-1">
            <div className="h-2 bg-white/15 rounded w-full" />
            <div className="h-2 bg-white/10 rounded w-5/6" />
            <div className="h-2 bg-white/10 rounded w-4/6" />
          </div>
          <div className="flex items-center gap-1 text-[10px] text-green-400">
            <CheckCircle2 className="w-2.5 h-2.5" /> Verified · 92 GCS Score
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── FAQ ──────────────────────────────────────────────────────────────────────

const FAQS = [
  { q: 'How did my products end up on GreenChainz?', a: 'We aggregate sustainable building material data from public sources including Sweets, EC3, manufacturer websites, and EPD databases. If your products are out there, they\'re likely already in our catalog — we just don\'t have everything needed to make the listing compelling.' },
  { q: 'What if I don\'t have EPDs yet?', a: 'We list you anyway and flag your profile as "EPD in progress." We can recommend EPD program operators to get you verified fast. Having a plan scores better than competitors with no plan at all.' },
  { q: 'How long does the white-glove setup take?', a: 'Our team completes your full profile within 48 hours of receiving your materials. You review and approve. Done. You need to provide: company description, product list, any EPD PDFs you have, certifications, logo, and product photos if available.' },
  { q: 'What does it cost?', a: 'The Founding 50 program is completely free. We onboard you, build your profile, and you get full premium access at no charge. We make money when architects send you RFQs and deals close — your success is our business model.' },
  { q: 'Can I update my profile myself after onboarding?', a: 'Yes — you get a full supplier dashboard where you can add products, upload new EPDs, update certifications, and respond to RFQs. We set it up, you run it.' },
]

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-white/10 last:border-0">
      <button onClick={() => setOpen(v => !v)} className="w-full flex items-center justify-between py-4 text-left group">
        <span className="text-white font-medium text-sm group-hover:text-green-400 transition-colors pr-4">{q}</span>
        <ChevronDown className={`w-4 h-4 text-gray-500 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <p className="text-gray-400 text-sm leading-relaxed pb-4">{a}</p>}
    </div>
  )
}

// ─── Request form ─────────────────────────────────────────────────────────────

function RequestForm({ prefillCompany }: { prefillCompany?: string }) {
  const [form, setForm] = useState({
    companyName: prefillCompany ?? '',
    contactName: '',
    email: '',
    phone: '',
    productCategories: '',
    hasEpds: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  // Update prefill if parent passes a company name
  useEffect(() => {
    if (prefillCompany) setForm(f => ({ ...f, companyName: prefillCompany }))
  }, [prefillCompany])

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async () => {
    if (!form.companyName || !form.email || !form.contactName) {
      toast.error('Company name, your name, and email are required.')
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/supplier/request-onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error()
      setSubmitted(true)
    } catch {
      toast.error('Something went wrong. Email us directly at jerit@greenchainz.com')
    } finally {
      setSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-4 py-8 text-center">
        <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-green-400" />
        </div>
        <h3 className="text-white font-bold text-xl">You're on the list.</h3>
        <p className="text-gray-400 text-sm max-w-xs">Jerit will reach out personally within 24 hours to get your profile live. Welcome to the Founding 50.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Company Name *</Label>
          <Input value={form.companyName} onChange={set('companyName')} placeholder="Acme Green Materials" className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Your Name *</Label>
          <Input value={form.contactName} onChange={set('contactName')} placeholder="Jane Smith" className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Work Email *</Label>
          <Input type="email" value={form.email} onChange={set('email')} placeholder="jane@acmegreenco.com" className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Phone</Label>
          <Input value={form.phone} onChange={set('phone')} placeholder="+1 (555) 000-0000" className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm" />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label className="text-gray-300 text-xs">What materials do you make?</Label>
        <Input value={form.productCategories} onChange={set('productCategories')} placeholder="e.g. Low-carbon concrete, recycled steel, FSC timber" className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm" />
      </div>
      <div className="space-y-1.5">
        <Label className="text-gray-300 text-xs">Do you have EPDs?</Label>
        <select value={form.hasEpds} onChange={set('hasEpds')} className="w-full h-9 bg-white/5 border border-white/10 text-sm rounded-md px-3 text-gray-300 focus:outline-none focus:border-green-500">
          <option value="">Select one</option>
          <option value="yes">Yes — verified EPDs</option>
          <option value="in-progress">In progress</option>
          <option value="no">Not yet</option>
          <option value="unsure">Not sure what an EPD is</option>
        </select>
      </div>
      <Button onClick={handleSubmit} disabled={submitting} className="w-full bg-green-500 hover:bg-green-400 text-black font-bold h-11 text-sm">
        {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</> : <>Claim My Profile Free <ArrowRight className="w-4 h-4 ml-2" /></>}
      </Button>
      <p className="text-center text-gray-600 text-xs">No payment. Jerit personally reaches out within 24 hours.</p>
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function SupplierLandingPage() {
  const [selectedCompany, setSelectedCompany] = useState<string | undefined>()

  return (
    <div className="min-h-screen bg-[#080808] text-white">

      {/* Nav */}
      <nav className="border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <Link href="/" className="text-green-400 font-bold text-lg tracking-tight">GreenChainz</Link>
        <a href="#request" className="text-sm text-gray-400 hover:text-white transition-colors">Claim your profile →</a>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-green-500/4 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-6 pt-20 pb-10 text-center">
          <div className="inline-flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
            <Eye className="w-3 h-3" /> Your products are already in our catalog
          </div>

          <h1 className="text-5xl sm:text-6xl font-black leading-[1.05] tracking-tight mb-6">
            Architects are already{' '}
            <span className="text-orange-400">seeing your listing.</span>
            <br />
            <span className="text-green-400">Is it working for you?</span>
          </h1>

          <p className="text-gray-400 text-lg leading-relaxed max-w-2xl mx-auto mb-10">
            We scraped your products from public databases. They're live on GreenChainz right now.
            But an unclaimed listing has no photos, no EPDs, no verified certifications — and loses
            to every competitor who claimed theirs.
          </p>

          {/* Live search */}
          <CompanySearch onSelect={(name) => {
            setSelectedCompany(name)
            // Scroll to profile preview
            setTimeout(() => document.getElementById('profile-preview')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100)
          }} />

          {/* Profile preview */}
          <div id="profile-preview">
            {selectedCompany && <ProfilePreview companyName={selectedCompany} />}
          </div>

          {!selectedCompany && (
            <p className="text-gray-600 text-sm mt-4">
              Type your company name above to see your current listing status.
            </p>
          )}
        </div>
      </section>

      {/* Before / After */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-3">What architects actually see</h2>
          <p className="text-gray-400 text-sm">Unclaimed vs. verified — same product, completely different outcome.</p>
        </div>
        <BeforeAfter />
      </section>

      {/* What we do */}
      <section className="bg-[#0c0c0c] border-y border-white/5 py-16">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-3">We fix everything. You approve. Done.</h2>
            <p className="text-gray-400 text-sm">Our team takes your bare listing and turns it into a profile that converts architects into RFQs.</p>
          </div>
          <div className="bg-[#0f0f0f] border border-green-500/15 rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-white/5 flex items-center gap-2">
              <Clock className="w-4 h-4 text-green-400" />
              <span className="text-green-400 font-semibold text-sm">Completed within 48 hours</span>
            </div>
            {[
              'Source and upload high-quality product photography',
              'Upload and index all your EPDs',
              'Map certifications to specific LEED v4.1 credits',
              'Write product descriptions optimized for architect searches',
              'Calculate and verify your GreenChainz Score',
              'Set up your supplier dashboard and RFQ inbox',
              'Test your profile against real architect search queries',
              'You review, approve, and go live',
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 px-5 py-3.5 border-t border-white/5">
                <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                <span className="text-gray-300 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founding 50 */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
            <Star className="w-3 h-3 fill-yellow-400" /> Founding 50 Program
          </div>
          <h2 className="text-3xl font-bold mb-3">First 50 suppliers. Free. Forever.</h2>
          <p className="text-gray-400 text-sm max-w-xl mx-auto">Everything is free for Founding 50 members — the setup, the verification, the premium access. You lock in your position before your category competitor does.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Star, label: 'Founding badge', desc: 'Permanent on your profile' },
            { icon: Zap, label: 'Premium free', desc: 'Instant RFQ access forever' },
            { icon: TrendingUp, label: 'Top placement', desc: 'First in your categories' },
            { icon: Lock, label: '$99/mo locked', desc: 'Others pay $299 when we go paid' },
          ].map(({ icon: Icon, label, desc }) => (
            <div key={label} className="bg-gradient-to-br from-yellow-500/5 to-transparent border border-yellow-500/15 rounded-xl p-4 text-center">
              <Icon className="w-5 h-5 text-yellow-400 mx-auto mb-2" />
              <p className="text-white font-semibold text-sm">{label}</p>
              <p className="text-gray-500 text-xs mt-0.5">{desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-5 flex items-center justify-between">
          <div>
            <p className="text-white font-semibold">Founding spots remaining</p>
            <p className="text-gray-500 text-sm">Program closes permanently at 50</p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-black text-green-400">47</div>
            <div className="text-gray-600 text-xs">of 50 left</div>
          </div>
        </div>
      </section>

      {/* Request form */}
      <section id="request" className="bg-[#0c0c0c] border-y border-white/5 py-16">
        <div className="max-w-xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-3">Claim Your Profile</h2>
            <p className="text-gray-400 text-sm">Jerit Norville, GreenChainz founder, personally reaches out within 24 hours. No sales team. No runaround.</p>
          </div>
          <div className="bg-[#0f0f0f] border border-white/10 rounded-2xl p-6">
            <RequestForm prefillCompany={selectedCompany} />
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-2xl mx-auto px-6 py-16">
        <h2 className="text-2xl font-bold text-center mb-8">Common questions</h2>
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl px-6">
          {FAQS.map((faq) => <FaqItem key={faq.q} {...faq} />)}
        </div>
      </section>

      {/* Final CTA */}
      <section className="max-w-2xl mx-auto px-6 pb-20 text-center">
        <div className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 rounded-2xl p-10">
          <Leaf className="w-8 h-8 text-green-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-3">Your listing is live right now.</h2>
          <p className="text-gray-400 text-sm mb-6 max-w-md mx-auto">The only question is whether it's working for you or against you.</p>
          <a href="#request">
            <Button className="bg-green-500 hover:bg-green-400 text-black font-bold px-10 h-12">
              Claim My Profile Free <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 px-6 py-8 text-center">
        <div className="text-gray-600 text-xs space-y-2">
          <p className="text-green-400 font-semibold text-sm">GreenChainz</p>
          <p>The verified sustainable materials marketplace for the AEC industry.</p>
          <p>Want to set up your profile yourself? <Link href="/supplier/onboarding" className="text-green-500 hover:text-green-400">Self-serve onboarding →</Link></p>
          <p className="pt-2">
            <Link href="/privacy" className="hover:text-gray-400">Privacy</Link> · <Link href="/terms" className="hover:text-gray-400">Terms</Link> · <a href="mailto:jerit@greenchainz.com" className="hover:text-gray-400">jerit@greenchainz.com</a>
          </p>
        </div>
      </footer>
    </div>
  )
}
