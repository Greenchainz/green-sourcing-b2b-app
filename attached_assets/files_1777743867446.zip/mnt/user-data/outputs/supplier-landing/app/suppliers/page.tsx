// app/suppliers/page.tsx
/**
 * Supplier-facing landing page.
 * Primary offer: white-glove onboarding (you do it for them).
 * Secondary: self-serve link buried at the bottom.
 *
 * Lead capture sends to /api/supplier/request-onboarding
 * which emails Jerit directly with the prospect's info.
 */
'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  CheckCircle2,
  ArrowRight,
  Zap,
  Shield,
  TrendingUp,
  Users,
  Award,
  Clock,
  ChevronDown,
  Loader2,
  AlertCircle,
  Star,
  Building2,
  Leaf,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'

// ─── Data ─────────────────────────────────────────────────────────────────────

const PAIN_POINTS = [
  {
    problem: 'Architects can\'t find you',
    solution: 'Your materials appear in every relevant search by architects specifying green buildings',
    icon: Users,
  },
  {
    problem: 'Your EPDs sit in a PDF nobody reads',
    solution: 'Your sustainability data becomes searchable, comparable, and linked to LEED credits automatically',
    icon: Shield,
  },
  {
    problem: 'Competitors with worse products get specified first',
    solution: 'GreenChainz ranks by actual sustainability score — your verified data beats their marketing claims',
    icon: TrendingUp,
  },
  {
    problem: 'RFQs go to whoever the architect already knows',
    solution: 'Architects on GreenChainz send RFQs to the best-matched verified supplier — that\'s you',
    icon: Zap,
  },
]

const WHAT_WE_DO = [
  'Create and optimize your supplier profile',
  'Upload and index all your EPDs',
  'Map your certifications to LEED v4.1 credits',
  'Write product descriptions architects actually search for',
  'Add high-quality product photography',
  'Verify your GreenChainz Score calculation',
  'Test your profile against real architect searches',
  'You go live within 48 hours — you touch nothing',
]

const FOUNDING_BENEFITS = [
  { label: 'Founding Member badge', desc: 'Permanent badge on your profile signaling early adopter status' },
  { label: 'Premium access — free', desc: 'Instant RFQ access, priority matching, analytics dashboard. Forever.' },
  { label: 'Top category placement', desc: 'Your products appear first in your categories as we grow' },
  { label: 'Locked pricing', desc: '$99/mo when we go paid — everyone else pays $299. You never pay more.' },
]

const FAQS = [
  {
    q: 'What if I don\'t have EPDs yet?',
    a: 'We list you anyway and flag your profile as "EPD in progress." We can also recommend EPD program operators to get you verified fast. Having an EPD in progress actually scores better than competitors with no plan at all.',
  },
  {
    q: 'How long does onboarding take?',
    a: 'Our team completes your full profile within 48 hours of receiving your materials. You review and approve. Done.',
  },
  {
    q: 'What do you need from me?',
    a: 'A 30-minute call or a quick email with: your company description, product list, any EPD PDFs you have, certifications, and your logo/product photos if available. We handle the rest.',
  },
  {
    q: 'What does it cost?',
    a: 'The Founding 50 program is completely free. We onboard you, set up your profile, and you get premium access at no charge. We make money when architects send you RFQs and deals close — your success is our business model.',
  },
  {
    q: 'Who are the architects on GreenChainz?',
    a: 'AEC professionals specifying materials for LEED, WELL, and other green building projects. These are high-value commercial projects — not residential — where your materials get specified at scale.',
  },
]

// ─── Components ───────────────────────────────────────────────────────────────

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-white/10 last:border-0">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between py-4 text-left group"
      >
        <span className="text-white font-medium text-sm group-hover:text-green-400 transition-colors pr-4">{q}</span>
        <ChevronDown className={`w-4 h-4 text-gray-500 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <p className="text-gray-400 text-sm leading-relaxed pb-4">{a}</p>}
    </div>
  )
}

// ─── Lead capture form ────────────────────────────────────────────────────────

function RequestForm() {
  const [form, setForm] = useState({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    productCategories: '',
    hasEpds: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async () => {
    if (!form.companyName || !form.email || !form.contactName) {
      toast.error('Please fill in company name, your name, and email.')
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/supplier/request-onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error()
      setSubmitted(true)
    } catch {
      toast.error('Something went wrong. Email us directly at jerit@greenchainz.com')
    } finally {
      setSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-4 py-8 text-center">
        <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-green-400" />
        </div>
        <h3 className="text-white font-bold text-xl">You're on the list.</h3>
        <p className="text-gray-400 text-sm max-w-xs">
          Jerit will reach out personally within 24 hours to schedule your onboarding. Welcome to the Founding 50.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Company Name *</Label>
          <Input
            placeholder="Acme Green Materials"
            value={form.companyName}
            onChange={set('companyName')}
            className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Your Name *</Label>
          <Input
            placeholder="Jane Smith"
            value={form.contactName}
            onChange={set('contactName')}
            className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Work Email *</Label>
          <Input
            type="email"
            placeholder="jane@acmegreenco.com"
            value={form.email}
            onChange={set('email')}
            className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-gray-300 text-xs">Phone</Label>
          <Input
            placeholder="+1 (555) 000-0000"
            value={form.phone}
            onChange={set('phone')}
            className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <Label className="text-gray-300 text-xs">What materials do you make?</Label>
        <Input
          placeholder="e.g. Low-carbon concrete, recycled steel framing, FSC timber"
          value={form.productCategories}
          onChange={set('productCategories')}
          className="bg-white/5 border-white/10 text-white placeholder:text-gray-600 focus:border-green-500 h-9 text-sm"
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-gray-300 text-xs">Do you have EPDs?</Label>
        <select
          value={form.hasEpds}
          onChange={set('hasEpds')}
          className="w-full h-9 bg-white/5 border border-white/10 text-sm rounded-md px-3 text-gray-300 focus:outline-none focus:border-green-500"
        >
          <option value="">Select one</option>
          <option value="yes">Yes — we have verified EPDs</option>
          <option value="in-progress">In progress — applying now</option>
          <option value="no">No — not yet</option>
          <option value="unsure">Not sure what an EPD is</option>
        </select>
      </div>

      <Button
        onClick={handleSubmit}
        disabled={submitting}
        className="w-full bg-green-500 hover:bg-green-400 text-black font-bold h-11 text-sm"
      >
        {submitting ? (
          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</>
        ) : (
          <>Request Your Free Onboarding <ArrowRight className="w-4 h-4 ml-2" /></>
        )}
      </Button>

      <p className="text-center text-gray-600 text-xs">
        No payment required. Jerit personally reaches out within 24 hours.
      </p>
    </div>
  )
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function SupplierLandingPage() {
  return (
    <div className="min-h-screen bg-[#080808] text-white">

      {/* ── Nav ──────────────────────────────────────────────────────────────── */}
      <nav className="border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <Link href="/" className="text-green-400 font-bold text-lg tracking-tight">
          GreenChainz
        </Link>
        <a
          href="#request"
          className="text-sm text-gray-400 hover:text-white transition-colors"
        >
          Get Started →
        </a>
      </nav>

      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-green-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
          <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 text-green-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
            <Star className="w-3 h-3 fill-green-400" />
            Founding 50 Supplier Program — Limited Spots
          </div>

          <h1 className="text-5xl sm:text-6xl font-black leading-[1.05] tracking-tight mb-6">
            If your product isn't{' '}
            <span className="text-green-400">in the database,</span>
            <br />
            it doesn't get specified.
          </h1>

          <p className="text-gray-400 text-lg leading-relaxed max-w-2xl mx-auto mb-8">
            Architects are moving to verified sustainable materials sourcing. GreenChainz is
            where they find, compare, and RFQ those materials. The Founding 50 suppliers get
            in free — and stay free — before their competitors do.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="#request">
              <Button className="bg-green-500 hover:bg-green-400 text-black font-bold px-8 h-12 text-base">
                Request Free Onboarding
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </a>
            <a href="#how-it-works">
              <Button variant="outline" className="border-white/10 text-gray-300 hover:text-white h-12 text-base px-8">
                See How It Works
              </Button>
            </a>
          </div>

          {/* Social proof */}
          <div className="flex items-center justify-center gap-6 mt-10 text-xs text-gray-600">
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> No payment required</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Live within 48 hours</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> We do all the work</span>
          </div>
        </div>
      </section>

      {/* ── The problem ──────────────────────────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">
            The architecture industry just changed.
            <span className="text-gray-500"> Did you notice?</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            LEED v4.1, embodied carbon mandates, and owner sustainability requirements have made verified green credentials table stakes — not a differentiator. Manufacturers without digital verification are being cut from spec lists.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {PAIN_POINTS.map(({ problem, solution, icon: Icon }) => (
            <div key={problem} className="bg-[#0f0f0f] border border-[#1a1a1a] rounded-xl p-5">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-4 h-4 text-red-400" />
                </div>
                <p className="text-gray-400 text-sm font-medium leading-snug">{problem}</p>
              </div>
              <div className="flex items-start gap-3 border-t border-white/5 pt-3">
                <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-green-400" />
                </div>
                <p className="text-white text-sm leading-snug">{solution}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ─────────────────────────────────────────────────────── */}
      <section id="how-it-works" className="bg-[#0c0c0c] border-y border-white/5 py-16">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">We do everything. You approve and go live.</h2>
            <p className="text-gray-400">Our team handles your entire onboarding. You don't need to learn new software or spend days filling out forms.</p>
          </div>

          <div className="bg-[#0f0f0f] border border-green-500/15 rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-white/5">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4 text-green-400" />
                <span className="text-green-400 font-semibold text-sm">What we do in 48 hours</span>
              </div>
              <p className="text-gray-500 text-xs">Everything below is handled by GreenChainz — not you.</p>
            </div>
            <div className="divide-y divide-white/5">
              {WHAT_WE_DO.map((item, i) => (
                <div key={i} className="flex items-center gap-3 px-6 py-3.5">
                  <div className="w-5 h-5 rounded-full bg-green-500/10 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-3 h-3 text-green-400" />
                  </div>
                  <span className="text-gray-300 text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Founding 50 benefits ─────────────────────────────────────────────── */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-xs font-semibold px-3 py-1.5 rounded-full mb-4">
            <Star className="w-3 h-3 fill-yellow-400" /> Founding 50 Program
          </div>
          <h2 className="text-3xl font-bold mb-3">
            First in. Best positioned. Permanently.
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto text-sm">
            The Founding 50 suppliers get benefits that never expire. Once the program closes, these terms are gone.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {FOUNDING_BENEFITS.map(({ label, desc }) => (
            <div key={label} className="bg-gradient-to-br from-yellow-500/5 to-transparent border border-yellow-500/15 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-semibold text-sm mb-1">{label}</p>
                  <p className="text-gray-500 text-xs leading-relaxed">{desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Spots counter */}
        <div className="mt-8 bg-[#0f0f0f] border border-white/10 rounded-xl p-5 flex items-center justify-between">
          <div>
            <p className="text-white font-semibold">Founding spots remaining</p>
            <p className="text-gray-500 text-sm">Program closes at 50 verified suppliers</p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-black text-green-400">47</div>
            <div className="text-gray-600 text-xs">of 50 left</div>
          </div>
        </div>
      </section>

      {/* ── Request form ─────────────────────────────────────────────────────── */}
      <section id="request" className="bg-[#0c0c0c] border-y border-white/5 py-16">
        <div className="max-w-xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-3">Request Your Free Onboarding</h2>
            <p className="text-gray-400 text-sm">
              Jerit Norville, GreenChainz founder, personally reaches out within 24 hours to schedule your setup call. No sales team. No runaround.
            </p>
          </div>

          <div className="bg-[#0f0f0f] border border-white/10 rounded-2xl p-6">
            <RequestForm />
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────────────────────────── */}
      <section className="max-w-2xl mx-auto px-6 py-16">
        <h2 className="text-2xl font-bold text-center mb-8">Common questions</h2>
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl px-6">
          {FAQS.map((faq) => (
            <FaqItem key={faq.q} q={faq.q} a={faq.a} />
          ))}
        </div>
      </section>

      {/* ── Final CTA ────────────────────────────────────────────────────────── */}
      <section className="max-w-2xl mx-auto px-6 pb-20 text-center">
        <div className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 rounded-2xl p-10">
          <Leaf className="w-8 h-8 text-green-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-3">
            Your competitors are going to be on here.
          </h2>
          <p className="text-gray-400 text-sm mb-6 max-w-md mx-auto">
            The question is whether they get there first. Founding 50 slots don't come back.
          </p>
          <a href="#request">
            <Button className="bg-green-500 hover:bg-green-400 text-black font-bold px-10 h-12">
              Secure Your Spot Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </a>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────────────── */}
      <footer className="border-t border-white/5 px-6 py-8 text-center">
        <div className="text-gray-600 text-xs space-y-2">
          <p className="text-green-400 font-semibold text-sm">GreenChainz</p>
          <p>The verified sustainable materials marketplace for the AEC industry.</p>
          <p>
            Want to set up your profile yourself?{' '}
            <Link href="/supplier/onboarding" className="text-green-500 hover:text-green-400">
              Self-serve onboarding →
            </Link>
          </p>
          <p className="pt-2">
            <Link href="/privacy" className="hover:text-gray-400">Privacy</Link>
            {' · '}
            <Link href="/terms" className="hover:text-gray-400">Terms</Link>
            {' · '}
            <a href="mailto:jerit@greenchainz.com" className="hover:text-gray-400">jerit@greenchainz.com</a>
          </p>
        </div>
      </footer>
    </div>
  )
}
