// app/api/supplier/request-onboarding/route.ts
/**
 * POST /api/supplier/request-onboarding
 *
 * No auth required — this is a public lead capture form.
 * Sends an email to Jerit with the prospect's details.
 * Also saves the lead to the DB for tracking.
 *
 * Body:
 *   companyName, contactName, email, phone?, productCategories?, hasEpds?
 */

import { NextRequest, NextResponse } from 'next/server'
import { sendFounderNewSupplierAlert } from '@/server/services/email-service'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const REQUIRED = ['companyName', 'contactName', 'email'] as const

export async function POST(req: NextRequest) {
  let body: Record<string, string>
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  // Validate required fields
  for (const field of REQUIRED) {
    if (!body[field]?.trim()) {
      return NextResponse.json({ error: `${field} is required` }, { status: 400 })
    }
  }

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(body.email)) {
    return NextResponse.json({ error: 'Invalid email address' }, { status: 400 })
  }

  try {
    // Send alert email to Jerit
    // Uses your existing sendFounderNewSupplierAlert — we're extending it with more detail
    await sendFounderNewSupplierAlert({
      supplierName: body.companyName,
      contactName: body.contactName,
      email: body.email,
      phone: body.phone ?? null,
      productCategories: body.productCategories ?? null,
      hasEpds: body.hasEpds ?? null,
      source: 'white-glove-landing-page',
      // The email service will format this into a clean notification
    })

    // TODO: optionally save to a `onboarding_leads` table in Drizzle for tracking
    // await db.insert(onboardingLeads).values({
    //   companyName: body.companyName,
    //   contactName: body.contactName,
    //   email: body.email,
    //   phone: body.phone ?? null,
    //   productCategories: body.productCategories ?? null,
    //   hasEpds: body.hasEpds ?? null,
    //   source: 'landing-page',
    //   status: 'new',
    //   createdAt: new Date(),
    // })

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('[OnboardingLead] Failed to send alert:', err)
    // Still return success to user — don't show backend errors on a lead form
    // But log it so you can follow up manually
    return NextResponse.json({ success: true })
  }
}
