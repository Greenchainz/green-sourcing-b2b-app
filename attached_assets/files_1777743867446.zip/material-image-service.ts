// server/services/material-image-service.ts
/**
 * Material Image Pipeline
 *
 * Two sources for images:
 *   1. Manufacturer website scraping (white-glove onboarding, admin-triggered)
 *   2. Direct supplier upload (self-serve, via /api/supplier/upload-image)
 *
 * All images land in Azure Blob Storage → "material-images" container
 * Blob naming: material-images/{supplierId}/{materialId}/{timestamp}.webp
 *
 * The scraper uses Playwright (already in the codebase for Sweets scraping).
 */

import { getDb } from '../db'
import { materials, manufacturers } from '../../drizzle/schema'
import { eq, isNull } from 'drizzle-orm'
import { uploadBlob } from '../../lib/azure/blob-storage'

const CONTAINER = 'material-images'
const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024 // 5MB hard cap
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp']

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ImageScrapeResult {
  materialId: number
  success: boolean
  imageUrl?: string
  blobName?: string
  error?: string
}

export interface ImageUploadResult {
  success: boolean
  imageUrl: string
  blobName: string
}

// ─── Fetch image buffer from a URL ───────────────────────────────────────────

async function fetchImageBuffer(url: string): Promise<{ buffer: Buffer; contentType: string } | null> {
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; GreenChainz/1.0; +https://greenchainz.com)',
      },
      signal: AbortSignal.timeout(10_000),
    })

    if (!res.ok) return null

    const contentType = res.headers.get('content-type') ?? ''
    const baseType = contentType.split(';')[0].trim()

    if (!ACCEPTED_TYPES.includes(baseType)) return null

    const arrayBuffer = await res.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    if (buffer.length > MAX_IMAGE_SIZE_BYTES) return null

    return { buffer, contentType: baseType }
  } catch {
    return null
  }
}

// ─── Upload buffer to Azure Blob ─────────────────────────────────────────────

async function uploadImageToBlob(
  buffer: Buffer,
  contentType: string,
  materialId: number,
  supplierId: number
): Promise<{ url: string; blobName: string }> {
  const ext = contentType === 'image/png' ? 'png' : contentType === 'image/webp' ? 'webp' : 'jpg'
  const blobName = `${supplierId}/${materialId}/${Date.now()}.${ext}`

  const result = await uploadBlob(CONTAINER, blobName, buffer, {
    contentType,
    metadata: {
      materialId: String(materialId),
      supplierId: String(supplierId),
      source: 'scraper',
    },
    tags: {
      materialId: String(materialId),
      type: 'product-image',
    },
  })

  return { url: result.url, blobName }
}

// ─── Scrape images from manufacturer website using Playwright ─────────────────

export async function scrapeManufacturerImages(
  manufacturerId: number,
  websiteUrl: string
): Promise<ImageScrapeResult[]> {
  // Dynamic import — Playwright is a heavy dep, only load when needed
  const { chromium } = await import('playwright')

  const db = await getDb()
  if (!db) throw new Error('Database not available')

  // Get all materials for this manufacturer that don't have images yet
  const pending = await db
    .select()
    .from(materials)
    .where(eq(materials.manufacturerId, manufacturerId))

  if (pending.length === 0) return []

  const results: ImageScrapeResult[] = []
  const browser = await chromium.launch({ headless: true })

  try {
    const page = await browser.newPage()

    // Navigate to manufacturer's products/sustainability page
    const urlsToTry = [
      websiteUrl,
      `${websiteUrl}/products`,
      `${websiteUrl}/materials`,
      `${websiteUrl}/sustainability`,
    ]

    for (const material of pending) {
      let found = false

      for (const baseUrl of urlsToTry) {
        try {
          await page.goto(baseUrl, { waitUntil: 'domcontentloaded', timeout: 15_000 })

          // Strategy: search for an img tag near the product name
          const productName = (material.productName || material.name).toLowerCase()

          const imageUrl = await page.evaluate((pName) => {
            // Find headings/text that contain the product name
            const allText = Array.from(document.querySelectorAll('h1,h2,h3,h4,p,span,div'))
            for (const el of allText) {
              if (el.textContent?.toLowerCase().includes(pName)) {
                // Look for nearby image
                const parent = el.closest('section,article,div[class*="product"],div[class*="card"]')
                if (parent) {
                  const img = parent.querySelector('img[src]') as HTMLImageElement | null
                  if (img?.src && !img.src.includes('logo') && !img.src.includes('icon')) {
                    return img.src
                  }
                }
              }
            }
            // Fallback: first large product-looking image on the page
            const imgs = Array.from(document.querySelectorAll('img[src]')) as HTMLImageElement[]
            const big = imgs.find(
              (img) =>
                img.naturalWidth > 200 &&
                img.naturalHeight > 200 &&
                !img.src.includes('logo') &&
                !img.src.includes('icon') &&
                !img.src.includes('banner')
            )
            return big?.src ?? null
          }, productName)

          if (imageUrl) {
            const fetched = await fetchImageBuffer(imageUrl)
            if (fetched) {
              // Use supplierId=0 for manufacturer-level images (no specific supplier yet)
              const { url, blobName } = await uploadImageToBlob(
                fetched.buffer,
                fetched.contentType,
                material.id,
                manufacturerId
              )

              // Persist to DB
              await db
                .update(materials)
                .set({
                  imageUrl: url,
                  imageBlobName: blobName,
                  imageUpdatedAt: new Date(),
                } as any)
                .where(eq(materials.id, material.id))

              results.push({ materialId: material.id, success: true, imageUrl: url, blobName })
              found = true
              break
            }
          }
        } catch (err) {
          // Try next URL
        }
      }

      if (!found) {
        results.push({
          materialId: material.id,
          success: false,
          error: 'No suitable image found on manufacturer website',
        })
      }
    }
  } finally {
    await browser.close()
  }

  return results
}

// ─── Direct upload (supplier self-serve or admin white-glove) ─────────────────

export async function uploadMaterialImageFromBuffer(
  materialId: number,
  supplierId: number,
  buffer: Buffer,
  contentType: string
): Promise<ImageUploadResult> {
  if (!ACCEPTED_TYPES.includes(contentType)) {
    throw new Error(`Unsupported image type: ${contentType}. Use JPEG, PNG, or WebP.`)
  }

  if (buffer.length > MAX_IMAGE_SIZE_BYTES) {
    throw new Error('Image too large. Maximum size is 5MB.')
  }

  const db = await getDb()
  if (!db) throw new Error('Database not available')

  const { url, blobName } = await uploadImageToBlob(buffer, contentType, materialId, supplierId)

  await db
    .update(materials)
    .set({
      imageUrl: url,
      imageBlobName: blobName,
      imageUpdatedAt: new Date(),
    } as any)
    .where(eq(materials.id, materialId))

  return { success: true, imageUrl: url, blobName }
}

// ─── Backfill: run scraper for all materials missing images ───────────────────

export async function backfillMissingImages(): Promise<{
  attempted: number
  succeeded: number
  failed: number
  errors: string[]
}> {
  const db = await getDb()
  if (!db) throw new Error('Database not available')

  // Get manufacturers that have materials with no images and have a website
  const mfrs = await db
    .select()
    .from(manufacturers)
    .where(eq(manufacturers.verified, true))

  let attempted = 0
  let succeeded = 0
  let failed = 0
  const errors: string[] = []

  for (const mfr of mfrs) {
    if (!mfr.website) continue

    try {
      const results = await scrapeManufacturerImages(mfr.id, mfr.website)
      attempted += results.length
      succeeded += results.filter((r) => r.success).length
      failed += results.filter((r) => !r.success).length
      errors.push(
        ...results
          .filter((r) => !r.success && r.error)
          .map((r) => `Material ${r.materialId}: ${r.error}`)
      )
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error'
      errors.push(`Manufacturer ${mfr.id} (${mfr.name}): ${msg}`)
      failed++
    }
  }

  console.log(`[ImagePipeline] Backfill complete: ${succeeded}/${attempted} succeeded`)
  return { attempted, succeeded, failed, errors }
}
