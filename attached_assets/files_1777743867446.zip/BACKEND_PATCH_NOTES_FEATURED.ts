// BACKEND_PATCH_NOTES_FEATURED.ts
//
// ─── 1. Register featuredRouter in your main tRPC router ──────────────────────
//
// In server/routers/index.ts (or wherever your appRouter is defined):
//
//   import { featuredRouter } from './featuredRouter'
//
//   export const appRouter = router({
//     // ... existing routers ...
//     featured: featuredRouter,
//   })
//
// ─── 2. Add to catalog query — featured materials sort to top ─────────────────
//
// In your materials tRPC query or /api/materials route, change the ORDER BY:
//
//   // Before:
//   .orderBy(desc(materials.sustainabilityScore))
//
//   // After (featured first, then by score):
//   .orderBy(
//     desc((materials as any).isFeatured),
//     desc(materials.sustainabilityScore)
//   )
//
// ─── 3. Add FeaturedRow to catalog page ───────────────────────────────────────
//
// In app/catalog/page.tsx, import and add above the main grid:
//
//   import { FeaturedRow } from '@/components/catalog/FeaturedRow'
//
//   // Fetch featured materials (add to your useEffect or tRPC call):
//   const [featuredMaterials, setFeaturedMaterials] = useState([])
//   useEffect(() => {
//     fetch('/api/trpc/featured.getFeaturedMaterials', { credentials: 'include' })
//       .then(r => r.json())
//       .then(d => setFeaturedMaterials(d.result?.data ?? []))
//       .catch(() => {}) // silent fail — featured row is non-critical
//   }, [])
//
//   // In JSX, above the main grid:
//   <FeaturedRow
//     materials={featuredMaterials}
//     onAddToQuote={addToBasket}
//     basketIds={basketIds}
//   />
//
// ─── 4. Add admin nav link ────────────────────────────────────────────────────
//
// Add to your admin sidebar or wherever admin nav lives:
//   { label: 'Featured Placements', href: '/admin/featured', icon: Star }
//
// ─── 5. Pricing to charge (enforce manually for now) ─────────────────────────
//
//   Featured Material:  $99/mo  (1 slot per category)
//   Featured Supplier:  $299/mo (all materials boosted + badge)
//
// When a supplier pays, you go to /admin/featured, enter their ID, set duration.
// That's it. No Stripe needed yet — invoice them manually.
//
// ─── 6. Auto-expiry (future improvement) ─────────────────────────────────────
//
// The featuredUntil column handles expiry. Featured materials with a past
// featuredUntil date are automatically excluded from getFeaturedMaterials.
// You can add an Azure Timer Function to clean up expired rows nightly if desired.
